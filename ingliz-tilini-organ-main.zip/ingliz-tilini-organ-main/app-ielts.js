/* ============================================================
   app-ielts.js - Advanced IELTS Engine (With Dual Answering Modes)
   ============================================================ */
'use strict';

window.appIeltsLoaded = true;
window.IELTS_LOADED = true;

function getCustomListening() { if (!STATE.customListening) STATE.customListening = []; return STATE.customListening; }
function getCustomReading() { if (!STATE.customReading) STATE.customReading = []; return STATE.customReading; }
function getCustomSpeaking() { if (!STATE.customSpeaking) STATE.customSpeaking = []; return STATE.customSpeaking; }
function getCustomWriting() { if (!STATE.customWriting) STATE.customWriting = []; return STATE.customWriting; }

function initCompletedIelts() {
  try {
    if (typeof STATE !== 'undefined' && !STATE.completedIelts) {
      STATE.completedIelts = { listening: [], reading: [], writing: [], speaking: [] };
      save();
    }
  } catch (e) {
    console.warn("IELTS State initialization postponed.");
  }
}

// ---------------- LISTENING WITH MULTIPLE CHOICE AND TYPING ----------------
function renderListening(root) {
  const cefrNow = getCefrLevel((typeof STATE !== 'undefined' ? STATE.points : 0) || 0);
  const allListening = [...SEED_LISTENING_LEVELS, ...getCustomListening()];
  const q = getNextIeltsQuestion('listening', cefrNow.id, allListening);

  if (typeof window.ieltsAnswerMode === 'undefined') {
    window.ieltsAnswerMode = 'options';
  }
  let mode = q.options ? window.ieltsAnswerMode : 'typing';

  root.innerHTML = `
    <h1>🎧 Listening (${cefrNow.id})</h1>
    <div class="card center" style="padding: 24px;">
      <button class="speak" id="playAudio" style="width: 80px; height: 80px; font-size: 36px; border-radius: 50%;">🔊</button>
      <p class="muted" style="margin-top: 12px; font-weight: 600;">Audio tinglash uchun bosing</p>
    </div>

    <!-- Mode Selector Toggle -->
    ${q.options ? `
    <div style="display: flex; justify-content: center; gap: 8px; margin-bottom: 14px;">
      <button class="btn sm ${mode === 'options' ? '' : 'sec'}" id="modeOpt" style="width:auto; border-radius:999px; padding:6px 12px; font-size:12px;">🔘 Variantlar</button>
      <button class="btn sm ${mode === 'typing' ? '' : 'sec'}" id="modeType" style="width:auto; border-radius:999px; padding:6px 12px; font-size:12px;">✍️ Yozma javob</button>
    </div>
    ` : ''}

    <div class="card">
      <h3>Savol:</h3>
      <p style="font-weight: 700; font-size: 16px; margin: 4px 0 14px 0;">${esc(q.q)}</p>
      
      <!-- Options Container -->
      <div id="listenOptContainer" style="display: ${mode === 'options' ? 'block' : 'none'};">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
          ${q.options ? q.options.map(opt => `
            <button class="btn sec ielts-opt-btn" data-opt="${esc(opt)}" style="min-height: 54px; font-size: 14px; padding: 8px 6px; text-align: center; white-space: normal; line-height: 1.3;">${esc(opt)}</button>
          `).join('') : ''}
        </div>
      </div>

      <!-- Typing Container -->
      <div id="listenTypeContainer" style="display: ${mode === 'typing' ? 'block' : 'none'};">
        <input id="listenAns" placeholder="Javobingizni inglizcha yozing..." style="margin-bottom: 8px;" />
        ${cefrNow.id === 'A1' ? `<div style="font-size: 11px; color: var(--warn); margin-bottom: 12px;">💡 Maslahat: Matn yoki audiodagi javobni qisqa qilib yozing.</div>` : ''}
        <button class="btn" id="checkListen">Tekshirish</button>
      </div>
    </div>

    <div id="listenFeedback"></div>
    
    <div style="display: flex; gap: 8px; margin-top: 10px;">
      <button class="btn sec" id="bIelts">← Chiqish</button>
      <button class="btn ok" id="nextListen" style="display:none;">Keyingi savol →</button>
    </div>
  `;

  $('#bIelts').onclick = () => go('ielts');
  $('#playAudio').onclick = () => speak(q.text);

  // Auto-speak on enter
  if (typeof STATE !== 'undefined' && STATE.settings && STATE.settings.autoSpeak) {
    setTimeout(() => speak(q.text), 600);
  }

  if (q.options) {
    $('#modeOpt').onclick = () => { window.ieltsAnswerMode = 'options'; renderListening(root); };
    $('#modeType').onclick = () => { window.ieltsAnswerMode = 'typing'; renderListening(root); };
  }

  const evaluateAnswer = (uAns) => {
    if (!uAns) { toast("Javob yozilmadi!", "err"); return; }
    const score = calculateMatchScore(uAns, q.a, q.keywords);
    const fb = $('#listenFeedback');
    
    let grade = "wrong";
    let message = `❌ Xato. To'g'ri javob: <b>${esc(q.a)}</b>`;
    let xpAward = 0;
    const passThreshold = (cefrNow.id === 'A1' || cefrNow.id === 'A2') ? 60 : 80;

    if (score >= 85) {
      grade = "correct";
      message = `🎉 To'g'ri javob! (+10 ball)`;
      xpAward = 10;
      buzzOk();
    } else if (score >= passThreshold) {
      grade = "partial";
      message = `👍 Yaqin javob! Qabul qilindi. To'g'ri javob: <b>${esc(q.a)}</b> (+7 ball)`;
      xpAward = 7;
      buzzOk();
    } else {
      buzzWrong();
    }

    fb.innerHTML = `
      <div class="card" style="border: 2px solid ${grade === 'correct' || grade === 'partial' ? 'var(--ok)' : 'var(--err)'}; background: rgba(39,196,152,0.08); animation: pop 0.3s;">
        <p style="margin: 0; font-size: 14px; font-weight: 600;">${message}</p>
        <p style="margin: 6px 0 0 0; font-size: 12px; color: var(--muted);">Audiodagi matn: "${esc(q.text)}"</p>
      </div>
    `;

    if (typeof STATE !== 'undefined' && STATE.completedIelts && !STATE.completedIelts.listening.includes(q.id)) {
      STATE.completedIelts.listening.push(q.id);
    }
    
    addPoints(xpAward);
    trackPassport(cefrNow.id, 'read');
    save();

    // Disable inputs and highlight correct
    $$('.ielts-opt-btn', root).forEach(btn => {
      btn.disabled = true;
      if (btn.dataset.opt.toLowerCase() === q.a.toLowerCase()) {
        btn.style.background = 'var(--ok)';
        btn.style.borderColor = 'var(--ok)';
        btn.style.color = '#fff';
      } else if (btn.dataset.opt.toLowerCase() === uAns.toLowerCase() && uAns.toLowerCase() !== q.a.toLowerCase()) {
        btn.style.background = 'var(--err)';
        btn.style.borderColor = 'var(--err)';
        btn.style.color = '#fff';
      }
    });

    const checkBtn = $('#checkListen'); if (checkBtn) checkBtn.disabled = true;
    const ansInp = $('#listenAns'); if (ansInp) ansInp.disabled = true;
    $('#nextListen').style.display = 'block';
  };

  $$('.ielts-opt-btn', root).forEach(btn => {
    btn.onclick = () => evaluateAnswer(btn.dataset.opt);
  });

  const checkBtn = $('#checkListen');
  if (checkBtn) {
    checkBtn.onclick = () => evaluateAnswer($('#listenAns').value.trim());
  }

  $('#nextListen').onclick = () => go('ielts_listening');
}

// ---------------- AQLLI TEKSHIRUV TIZIMI ----------------
function cleanText(str) {
  if (!str) return "";
  return str.toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?]/g,"") 
    .replace(/\b(a|an|the|to|in|on|at|of|for|with|by|is|are|am|was|were)\b/g, "") 
    .replace(/\s+/g, " ") 
    .trim();
}

function calculateMatchScore(user, correct, keywords) {
  const u = cleanText(user);
  const c = cleanText(correct);
  if (!u) return 0;
  if (u === c) return 100;

  if (keywords && keywords.length > 0) {
    for (let kw of keywords) {
      if (u.includes(cleanText(kw)) || cleanText(kw).includes(u)) return 100;
    }
  }

  if (u.includes(c) || c.includes(u)) {
    return 90;
  }

  const distance = levDistance(u, c);
  const maxLen = Math.max(u.length, c.length);
  return ((maxLen - distance) / maxLen) * 100;
}

function levDistance(a, b) {
  const matrix = [];
  for (let i = 0; i <= b.length; i++) matrix[i] = [i];
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, 
          matrix[i][j - 1] + 1,     
          matrix[i - 1][j] + 1      
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

function getNextIeltsQuestion(section, level, pool) {
  initCompletedIelts();
  const levelPool = pool.filter(q => q.level === level);
  if (!levelPool.length) return pool[Math.floor(Math.random() * pool.length)];

  if (typeof STATE !== 'undefined' && STATE.completedIelts) {
    let available = levelPool.filter(q => !STATE.completedIelts[section].includes(q.id));
    
    if (available.length === 0) {
      STATE.completedIelts[section] = STATE.completedIelts[section].filter(id => !levelPool.some(q => q.id === id));
      save();
      available = levelPool;
    }
    return available[Math.floor(Math.random() * available.length)];
  }
  return levelPool[0];
}

// ---------------- IELTS DASHBOARD ----------------
registerRoute('ielts', (root) => {
  const pts = (typeof STATE !== 'undefined' ? STATE.points : 0) || 0;
  const cefrNow = getCefrLevel(pts);
  const band = estBand();

  root.innerHTML = `
    <h1>🎓 ${esc(t('ieltsTitle'))}</h1>
    <div class="card grad" style="margin-bottom: 16px;">
      <div style="font-size: 14px; opacity: 0.9;">Sizning darajangiz:</div>
      <div style="font-size: 24px; font-weight: 800; margin: 4px 0;">${cefrNow.icon} ${cefrNow.id} - ${cefrNow.name}</div>
      <div style="font-size: 13px; opacity: 0.85;">IELTS Band Score taxmini: <b>${band}</b></div>
    </div>

    <div class="grid2">
      <div class="card ielts-card" id="ieltsSpeak" style="cursor: pointer;">
        <div style="font-size: 32px; margin-bottom: 4px;">🎤</div>
        <h3 style="margin: 0;">${esc(t('speaking'))}</h3>
        <p class="muted" style="font-size: 11px; margin: 0;">Ovozni matnga o'tkazish mashqlari</p>
      </div>
      <div class="card ielts-card" id="ieltsWrite" style="cursor: pointer;">
        <div style="font-size: 32px; margin-bottom: 4px;">✍️</div>
        <h3 style="margin: 0;">${esc(t('writing'))}</h3>
        <p class="muted" style="font-size: 11px; margin: 0;">Insholar va andozalar tahlili</p>
      </div>
    </div>

    <div class="grid2" style="margin-top: 10px;">
      <div class="card ielts-card" id="ieltsListen" style="cursor: pointer;">
        <div style="font-size: 32px; margin-bottom: 4px;">🎧</div>
        <h3 style="margin: 0;">${esc(t('listening'))}</h3>
        <p class="muted" style="font-size: 11px; margin: 0;">Tinglab tushunish va yumshoq tahlil</p>
      </div>
      <div class="card ielts-card" id="ieltsRead" style="cursor: pointer;">
        <div style="font-size: 32px; margin-bottom: 4px;">📖</div>
        <h3 style="margin: 0;">${esc(t('reading'))}</h3>
        <p class="muted" style="font-size: 11px; margin: 0;">Matn o'qish va savol-javoblar</p>
      </div>
    </div>

    <button class="btn" id="ieltsAiImportBtn" style="background: linear-gradient(135deg, var(--pri), var(--ok)); color: #fff; border: none; margin-top: 18px; border-radius: 14px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 14px;">
      🤖 AI IELTS Savollarini qo'shish
    </button>
  `;

  $('#ieltsSpeak').onclick = () => go('ielts_speaking');
  $('#ieltsWrite').onclick = () => go('ielts_writing');
  $('#ieltsListen').onclick = () => go('ielts_listening');
  $('#ieltsRead').onclick = () => go('ielts_reading');
  $('#ieltsAiImportBtn').onclick = () => go('ielts_ai_import');
});

registerRoute('ielts_listening', (root) => {
  renderListening(root);
});

// ---------------- IELTS READING ----------------
registerRoute('ielts_reading', (root) => {
  const cefrNow = getCefrLevel((typeof STATE !== 'undefined' ? STATE.points : 0) || 0);
  const allReading = [...SEED_READING_LEVELS, ...getCustomReading()];

  // Session tizimi: bir marta shuffle, keyin ketma-ket
  if (!window.readSession || window.readSession.level !== cefrNow.id) {
    const pool = allReading.filter(q => q.level === cefrNow.id);
    const shuffled = pool.slice().sort(() => Math.random() - 0.5);
    window.readSession = { level: cefrNow.id, queue: shuffled, idx: 0, correct: 0, total: 0 };
  }

  const sess = window.readSession;

  // Barcha savollar tugasa — natija ekrani
  if (sess.idx >= sess.queue.length) {
    const pct = sess.total ? Math.round(sess.correct / sess.total * 100) : 0;
    root.innerHTML = `
      <h1>📖 Reading (${cefrNow.id})</h1>
      <div class="card grad center" style="padding: 28px 16px;">
        <div style="font-size: 48px;">📊</div>
        <div style="font-size: 32px; font-weight: 800; margin: 8px 0;">${sess.correct}/${sess.total}</div>
        <div style="font-size: 18px;">${pct}% to'g'ri</div>
        <div style="font-size: 13px; margin-top: 8px; opacity: 0.8;">${pct >= 80 ? '🎉 Ajoyib natija!' : pct >= 60 ? '👍 Yaxshi, davom eting!' : '💪 Ko\'proq mashq qiling!'}</div>
      </div>
      <button class="btn" id="readAgain" style="margin-top:12px;">🔄 Qayta boshlash</button>
      <button class="btn sec" id="bIelts" style="margin-top:8px;">← IELTS ga qaytish</button>
    `;
    $('#readAgain').onclick = () => { window.readSession = null; go('ielts_reading'); };
    $('#bIelts').onclick = () => { window.readSession = null; go('ielts'); };
    return;
  }

  const r = sess.queue[sess.idx];
  const qNum = sess.idx + 1;
  const qTotal = sess.queue.length;

  if (typeof window.ieltsAnswerMode === 'undefined') window.ieltsAnswerMode = 'options';
  let mode = r.options ? window.ieltsAnswerMode : 'typing';

  root.innerHTML = `
    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">
      <h1 style="margin:0;">📖 Reading (${cefrNow.id})</h1>
      <span style="font-size:13px; color:var(--muted); font-weight:700;">${qNum}/${qTotal}</span>
    </div>
    <div style="height:6px; background:var(--bg2); border-radius:4px; margin-bottom:14px;">
      <div style="height:6px; background:var(--pri); border-radius:4px; width:${Math.round((qNum-1)/qTotal*100)}%;"></div>
    </div>

    <div class="card">
      <h2 style="color: var(--pri2); margin-top: 0;">${esc(r.title)}</h2>
      <p style="font-size: 14px; line-height: 1.6; background: var(--bg2); padding: 14px; border-radius: 12px; border: 1px solid var(--line); white-space: pre-wrap;">${esc(r.text)}</p>
    </div>

    ${r.options ? `
    <div style="display: flex; justify-content: center; gap: 8px; margin-bottom: 14px;">
      <button class="btn sm ${mode === 'options' ? '' : 'sec'}" id="modeOpt" style="width:auto; border-radius:999px; padding:6px 12px; font-size:12px;">🔘 Variantlar</button>
      <button class="btn sm ${mode === 'typing' ? '' : 'sec'}" id="modeType" style="width:auto; border-radius:999px; padding:6px 12px; font-size:12px;">✍️ Yozma javob</button>
    </div>
    ` : ''}

    <div class="card">
      <h3>❓ Savol ${qNum}:</h3>
      <p style="font-weight: 700; font-size: 15px; margin: 4px 0 12px 0;">${esc(r.q)}</p>
      
      <div id="readOptContainer" style="display: ${mode === 'options' ? 'block' : 'none'};">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
          ${r.options ? r.options.map(opt => `
            <button class="btn sec ielts-opt-btn" data-opt="${esc(opt)}" style="min-height: 54px; font-size: 14px; padding: 8px 6px; text-align: center; white-space: normal; line-height: 1.3;">${esc(opt)}</button>
          `).join('') : ''}
        </div>
      </div>

      <div id="readTypeContainer" style="display: ${mode === 'typing' ? 'block' : 'none'};">
        <input id="readAns" placeholder="Javobingizni inglizcha yozing..." style="margin-bottom: 8px;" />
        ${cefrNow.id === 'A1' ? `<div style="font-size: 11px; color: var(--warn); margin-bottom: 12px;">💡 Maslahat: Matndagi javobni qisqa qilib yozing.</div>` : ''}
        <button class="btn" id="checkRead">Tekshirish</button>
      </div>
    </div>

    <div id="readFeedback"></div>

    <div style="display: flex; gap: 8px; margin-top: 10px;">
      <button class="btn sec" id="bIelts">← Chiqish</button>
      <button class="btn ok" id="nextRead" style="display:none;">${sess.idx + 1 < sess.queue.length ? 'Keyingi savol →' : '📊 Natijani ko\'rish'}</button>
    </div>
  `;

  $('#bIelts').onclick = () => go('ielts');

  if (r.options) {
    $('#modeOpt').onclick = () => { window.ieltsAnswerMode = 'options'; go('ielts_reading'); };
    $('#modeType').onclick = () => { window.ieltsAnswerMode = 'typing'; go('ielts_reading'); };
  }

  const evaluateAnswer = (uAns) => {
    if (!uAns) { toast("Javob yozilmadi!", "err"); return; }
    const score = calculateMatchScore(uAns, r.a, r.keywords);
    const fb = $('#readFeedback');

    let grade = "wrong";
    let message = `❌ Xato. To'g'ri javob: <b>${esc(r.a)}</b>`;
    let xpAward = 0;
    const passThreshold = (cefrNow.id === 'A1' || cefrNow.id === 'A2') ? 60 : 80;

    if (score >= 85) {
      grade = "correct";
      message = `🎉 To'g'ri! (+10 ball)`;
      xpAward = 10;
      sess.correct++;
      buzzOk();
    } else if (score >= passThreshold) {
      grade = "partial";
      message = `👍 Yaqin javob. To'g'risi: <b>${esc(r.a)}</b> (+7 ball)`;
      xpAward = 7;
      sess.correct++;
      buzzOk();
    } else {
      message = `❌ Xato. To'g'ri javob: <b>${esc(r.a)}</b>`;
      buzzWrong();
    }
    sess.total++;

    fb.innerHTML = `
      <div class="card" style="border: 2px solid ${grade !== 'wrong' ? 'var(--ok)' : 'var(--err)'}; background: rgba(39,196,152,0.08); animation: pop 0.3s;">
        <p style="margin: 0; font-size: 14px; font-weight: 600;">${message}</p>
      </div>
    `;

    if (typeof STATE !== 'undefined' && STATE.completedIelts && !STATE.completedIelts.reading.includes(r.id)) {
      STATE.completedIelts.reading.push(r.id);
    }

    addPoints(xpAward);
    trackPassport(cefrNow.id, 'read');
    save();

    $$('.ielts-opt-btn', root).forEach(btn => {
      btn.disabled = true;
      if (btn.dataset.opt.toLowerCase() === r.a.toLowerCase()) {
        btn.style.background = 'var(--ok)'; btn.style.borderColor = 'var(--ok)'; btn.style.color = '#fff';
      } else if (btn.dataset.opt.toLowerCase() === uAns.toLowerCase() && uAns.toLowerCase() !== r.a.toLowerCase()) {
        btn.style.background = 'var(--err)'; btn.style.borderColor = 'var(--err)'; btn.style.color = '#fff';
      }
    });

    const checkBtn = $('#checkRead'); if (checkBtn) checkBtn.disabled = true;
    const ansInp = $('#readAns'); if (ansInp) ansInp.disabled = true;
    $('#nextRead').style.display = 'block';
  };

  $$('.ielts-opt-btn', root).forEach(btn => { btn.onclick = () => evaluateAnswer(btn.dataset.opt); });
  const checkBtn = $('#checkRead');
  if (checkBtn) checkBtn.onclick = () => evaluateAnswer($('#readAns').value.trim());

  $('#nextRead').onclick = () => { sess.idx++; go('ielts_reading'); };
});

// ---------------- IELTS WRITING ----------------
registerRoute('ielts_writing', (root) => {
  const cefrNow = getCefrLevel((typeof STATE !== 'undefined' ? STATE.points : 0) || 0);
  const allWriting = [...SEED_WRITING_LEVELS, ...getCustomWriting()];
  const w = getNextIeltsQuestion('writing', cefrNow.id, allWriting);

  root.innerHTML = `
    <h1>✍️ Writing (${cefrNow.id})</h1>
    <div class="card">
      <h2 style="color: var(--pri2); margin-top: 0;">${esc(w.title)}</h2>
      <p style="font-size: 14px; font-weight: 600; background: var(--bg2); padding: 12px; border-radius: 10px; border: 1px solid var(--line);">${esc(w.prompt)}</p>
      <div style="font-size: 11px; color: var(--muted); margin-top: 4px;">Kamida <b>${w.minWords}</b> ta so'z yozishingiz kutiladi.</div>
    </div>

    <div class="card">
      <textarea id="essayInput" placeholder="Inshongizni ingliz tilida yozing..." style="min-height: 180px; font-size: 14px; line-height: 1.6;"></textarea>
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <span class="muted" style="font-size: 12px;">So'zlar soni: <b id="wc">0</b></span>
        <button class="btn sm" id="submitEssay" style="width: auto;">Inshoni topshirish</button>
      </div>
    </div>

    <div id="writingFeedback"></div>

    <button class="btn sec" id="bIelts" style="margin-top: 10px;">← Chiqish</button>
  `;

  $('#bIelts').onclick = () => go('ielts');

  const calcWc = (text) => text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
  const essayTxt = $('#essayInput');
  if (essayTxt) {
    essayTxt.oninput = (e) => { $('#wc').textContent = calcWc(e.target.value); };
  }

  $('#submitEssay').onclick = () => {
    const text = $('#essayInput').value.trim();
    const words = calcWc(text);

    const minRequired = Math.round(w.minWords * 0.8);
    if (words < minRequired) {
      toast(`⚠️ Insho biroz qisqa (kamida ${minRequired} ta so'z yozing)`, "err");
      return;
    }

    let matchPhrasesCount = 0;
    w.keyPhrases.forEach(kp => {
      if (text.toLowerCase().includes(kp.toLowerCase())) matchPhrasesCount++;
    });

    const phrasePercentage = (matchPhrasesCount / w.keyPhrases.length) * 100;
    let computedBand = 3.0;
    let feedbackMsg = "Yaxshi urinish! Bog'lovchi so'zlarni ko'proq ishlatishga harakat qiling.";

    if (words >= w.minWords) { computedBand += 1.5; }
    if (phrasePercentage >= 80) { computedBand += 2.0; feedbackMsg = "Ajoyib struktura va boy so'z boyligi!"; }
    else if (phrasePercentage >= 40) { computedBand += 1.0; feedbackMsg = "Muhim andozalardan foydalana oldingiz."; }

    computedBand = Math.min(9.0, computedBand).toFixed(1);

    const fb = $('#writingFeedback');
    fb.innerHTML = `
      <div class="card" style="border: 2px solid var(--ok); background: rgba(39,196,152,0.06);">
        <h3 style="color: var(--ok); margin-top: 0;">📊 Baholash tahlili</h3>
        <div style="font-size: 26px; font-weight: 800; color: var(--pri2); margin: 6px 0;">Estimated Band: ${computedBand}</div>
        <p style="font-size: 13px; margin: 4px 0;"><b>Taqriz:</b> ${feedbackMsg}</p>
        <p style="font-size: 11px; color: var(--muted); margin: 4px 0;">Yozilgan so'zlar: ${words}/${w.minWords} | Andozalar: ${matchPhrasesCount}/${w.keyPhrases.length}</p>
      </div>
    `;

    if (typeof STATE !== 'undefined' && STATE.completedIelts && !STATE.completedIelts.writing.includes(w.id)) {
      STATE.completedIelts.writing.push(w.id);
    }

    STATE.wroteOnce = true;
    addPoints(25);
    trackPassport(cefrNow.id, 'write');
    save();

    $('#submitEssay').disabled = true;
  };
});

// ---------------- IELTS SPEAKING ----------------
registerRoute('ielts_speaking', (root) => {
  const cefrNow = getCefrLevel((typeof STATE !== 'undefined' ? STATE.points : 0) || 0);
  const allSpeaking = [...SEED_SPEAKING_LEVELS, ...getCustomSpeaking()];
  const q = getNextIeltsQuestion('speaking', cefrNow.id, allSpeaking);

  root.innerHTML = `
    <h1>🎤 Speaking (${cefrNow.id})</h1>
    <div class="card">
      <div style="font-size: 12px; color: var(--pri2); font-weight: 700;">Question Part ${q.part}</div>
      <p style="font-weight: 700; font-size: 16px; margin: 8px 0;">"${esc(q.q)}"</p>
      <div style="font-size: 11px; color: var(--muted);">Savolga ingliz tilida baland ovozda javob bering.</div>
    </div>

    <div class="card center" style="padding: 24px;">
      <button class="btn" id="startSpeech" style="background: var(--err); font-size: 16px; max-width: 240px; margin: 0 auto; display: flex; align-items: center; justify-content: center; gap: 8px;">
        <span>🔴</span> Gapirishni boshlash
      </button>
      <div id="speakingWaves" style="display:none; margin-top:14px; color: var(--warn); font-size:12px; font-weight:700;">
        🎤 Ovoz matnga o'girilmoqda...
      </div>
      <textarea id="speechResult" readonly placeholder="Gapirgan so'zlaringiz shu yerda matn bo'lib ko'rinadi..." style="width: 100%; min-height: 90px; margin-top: 14px; font-size: 13px; font-style: italic; background: rgba(0,0,0,0.1); border: 1px dashed var(--line);"></textarea>
    </div>

    <div id="speechFeedback"></div>

    <button class="btn sec" id="bIelts" style="margin-top: 10px;">← Chiqish</button>
  `;

  $('#bIelts').onclick = () => {
    stopSpeechRecognition();
    go('ielts');
  };

  const recBtn = $('#startSpeech');
  const waves = $('#speakingWaves');
  const resultBox = $('#speechResult');
  const fb = $('#speechFeedback');

  let recognition = null;
  let isRecording = false;

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  function stopSpeechRecognition() {
    if (recognition) {
      recognition.stop();
      isRecording = false;
    }
  }

  if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript + ' ';
        }
      }
      if (finalTranscript) {
        resultBox.value = (resultBox.value + ' ' + finalTranscript).trim();
      }
    };

    recognition.onerror = () => {
      toast("Mikrofon xatoligi!", "err");
      waves.style.display = 'none';
    };

    recBtn.onclick = () => {
      if (!isRecording) {
        resultBox.value = "";
        try {
          recognition.start();
          isRecording = true;
          recBtn.innerHTML = `<span>⏹️</span> Gapirishni tugatish`;
          recBtn.style.background = 'var(--warn)';
          recBtn.style.color = '#222';
          waves.style.display = 'block';
        } catch(e) { toast("Mikrofonga ruxsat yo'q!", "err"); }
      } else {
        recognition.stop();
        isRecording = false;
        recBtn.innerHTML = `<span>🔴</span> Gapirishni boshlash`;
        recBtn.style.background = 'var(--err)';
        recBtn.style.color = '#fff';
        waves.style.display = 'none';
        
        evaluateSpeechResult();
      }
    };
  } else {
    let speakTimer = null;
    let mockSeconds = 0;
    
    recBtn.onclick = () => {
      if (!isRecording) {
        isRecording = true;
        mockSeconds = 0;
        recBtn.innerHTML = `<span>⏹️</span> Tugatish`;
        recBtn.style.background = 'var(--warn)';
        recBtn.style.color = '#222';
        waves.style.display = 'block';
        waves.textContent = "🎙️ Ovoz yozilmoqda (0 soniya)...";
        
        speakTimer = setInterval(() => {
          mockSeconds++;
          waves.textContent = `🎙️ Ovoz yozilmoqda (${mockSeconds} soniya)...`;
        }, 1000);
      } else {
        isRecording = false;
        clearInterval(speakTimer);
        recBtn.innerHTML = `<span>🔴</span> Gapirishni boshlash`;
        recBtn.style.background = 'var(--err)';
        recBtn.style.color = '#fff';
        waves.style.display = 'none';

        resultBox.value = `I think this is very interesting question. In my opinion, ${q.keywords.slice(0, 2).join(' and ')} are very popular.`;
        evaluateSpeechResult();
      }
    };
  }

  function evaluateSpeechResult() {
    const text = resultBox.value.trim().toLowerCase();
    const wordsCount = text === "" ? 0 : text.split(/\s+/).length;
    let foundKeywords = 0;

    q.keywords.forEach(kw => {
      if (text.includes(kw.toLowerCase())) foundKeywords++;
    });

    let rating = 3.5;
    let review = "Yaxshi harakat. Nutq davomiyligini biroz uzaytirish kerak.";

    if (wordsCount > 5) rating += 1.0;
    if (wordsCount > 15) rating += 1.0;
    if (foundKeywords > 0) { rating += 1.5; review = "Savolga mos kalit so'zlarni to'g'ri qo'lladingiz!"; }

    rating = Math.min(9.0, rating).toFixed(1);

    fb.innerHTML = `
      <div class="card" style="border: 2px solid var(--ok); background: rgba(39,196,152,0.06); margin-top:14px;">
        <h3 style="color: var(--ok); margin-top: 0;">🎤 Nutq tahlili</h3>
        <div style="font-size: 26px; font-weight: 800; color: var(--pri2); margin: 6px 0;">Speech Band: ${rating}</div>
        <p style="font-size: 13px; margin: 4px 0;"><b>Taqriz:</b> ${review}</p>
        <p style="font-size: 11px; color: var(--muted); margin: 4px 0;">So'zlar: ${wordsCount} | Kalit so'zlar: ${foundKeywords}/${q.keywords.length}</p>
      </div>
    `;

    if (typeof STATE !== 'undefined' && STATE.completedIelts && !STATE.completedIelts.speaking.includes(q.id)) {
      STATE.completedIelts.speaking.push(q.id);
    }

    STATE.spokeOnce = true;
    addPoints(20);
    trackPassport(cefrNow.id, 'speak');
    save();
  }
});

// ---------------- REAL-TIME AI IELTS QUESTION IMPORT ----------------
registerRoute('ielts_ai_import', (root) => {
  let selSection = 'listening';
  let selLevel = 'A1';
  let selCount = 10;

  function buildIeltsPrompt() {
    const secPrompts = {
      listening: `Menga ${selCount} ta IELTS Listening savoli bering.
Daraja: ${selLevel} (ingliz tili darajasiga to'g'ri kelsin).
Format: Faqat quyidagi toza JSON formatida javob bering, hech qanday ortiqcha matn, tushuntirish va markdownlarsiz yozing:
[
  {"id": "usr_li_${selLevel.toLowerCase()}_" + Date.now(), "level": "${selLevel}", "text": "Audioda talaffuz qilinadigan inglizcha matn.", "q": "Matn bo'yicha inglizcha savol?", "a": "Aniq va qisqa javob", "keywords": ["muhim", "kalit", "sozlar"]}
]`,
      reading: `Menga ${selCount} ta IELTS Reading matni va savoli bering.
Daraja: ${selLevel}.
Format: Faqat quyidagi JSON formatida javob bering, ortiqcha matnlarsiz:
[
  {"id": "usr_re_${selLevel.toLowerCase()}_" + Date.now(), "level": "${selLevel}", "title": "Mavzu sarlavhasi", "text": "Ingliz tilidagi o'qish matni.", "q": "Matn yuzasidan savol?", "a": "Aniq javob", "keywords": ["kalit"]}
]`,
      speaking: `Menga ${selCount} ta IELTS Speaking savoli bering.
Daraja: ${selLevel}.
Format: Faqat quyidagi JSON formatida javob bering:
[
  {"id": "usr_sp_${selLevel.toLowerCase()}_" + Date.now(), "level": "${selLevel}", "q": "Speaking savoli?", "keywords": ["taxminiy", "javob", "kalitlari"], "part": 1}
]`,
      writing: `Menga ${selCount} ta IELTS Writing mavzusi bering.
Daraja: ${selLevel}.
Format: Faqat quyidagi JSON formatida javob bering:
[
  {"id": "usr_wr_${selLevel.toLowerCase()}_" + Date.now(), "level": "${selLevel}", "title": "Insho sarlavhasi", "prompt": "Ushbu darajaga mos insho topshirig'i.", "minWords": 30, "keyPhrases": ["ishlatish", "kerakli", "iboralar"]}
]`,
    };
    return secPrompts[selSection] || secPrompts.listening;
  }

  function renderImportView() {
    const currentPrompt = buildIeltsPrompt();
    root.innerHTML = `
      <h1>🤖 AI orqali IELTS savollari qo'shish</h1>
      
      <div class="card">
        <h3>1️⃣ Bo'limni tanlang:</h3>
        <select id="selImportSec">
          <option value="listening" ${selSection==='listening'?'selected':''}>Listening</option>
          <option value="reading" ${selSection==='reading'?'selected':''}>Reading</option>
          <option value="speaking" ${selSection==='speaking'?'selected':''}>Speaking</option>
          <option value="writing" ${selSection==='writing'?'selected':''}>Writing</option>
        </select>

        <h3>2️⃣ Darajani tanlang:</h3>
        <select id="selImportLvl">
          ${CEFR_LEVELS.map(c => `<option value="${c.id}" ${selLevel===c.id?'selected':''}>${c.id} - ${c.name}</option>`).join('')}
        </select>

        <h3>3️⃣ Savollar soni:</h3>
        <select id="selImportCnt">
          <option value="5" ${selCount===5?'selected':''}>5 ta</option>
          <option value="10" ${selCount===10?'selected':''}>10 ta</option>
          <option value="20" ${selCount===20?'selected':''}>20 ta</option>
        </select>
      </div>

      <div class="card" style="background: rgba(109,94,252,0.15); border: 1px solid #6d5efc;">
        <div style="font-size: 13px; font-weight: 700; color: #a0a0ff; margin-bottom: 8px;">📋 Quyidagi promptni nusxalab ChatGPT yoki Claude ga yuboring:</div>
        <div id="ieltsPromptBox" style="font-size: 12px; line-height: 1.5; white-space: pre-wrap; background: rgba(0,0,0,0.3); padding: 10px; border-radius: 8px; max-height: 180px; overflow-y: auto;">${currentPrompt}</div>
        <button class="btn" id="copyIeltsPrompt" style="margin-top: 10px; font-size: 13px; padding: 10px;">📋 Promptni nusxalash</button>
      </div>

      <div class="card">
        <div style="font-size: 13px; font-weight: 700; margin-bottom: 8px;">✍️ AIdan olingan JSON javobini shu yerga joylashtiring (Paste):</div>
        <textarea id="ieltsPasteArea" placeholder='[ {"id": "...", "level": "...", ...} ]' style="min-height: 120px; font-size: 12px;"></textarea>
        <button class="btn ok" id="saveIeltsImport" style="margin-top: 10px;">💾 Savollarni bazaga qo'shish</button>
      </div>

      <button class="btn sec" id="bIelts">← IELTS bo'limiga qaytish</button>
    `;

    $('#bIelts').onclick = () => go('ielts');

    $('#selImportSec').onchange = (e) => { selSection = e.target.value; renderImportView(); };
    $('#selImportLvl').onchange = (e) => { selLevel = e.target.value; renderImportView(); };
    $('#selImportCnt').onchange = (e) => { selCount = parseInt(e.target.value); renderImportView(); };

    $('#copyIeltsPrompt').onclick = () => {
      navigator.clipboard.writeText(currentPrompt).then(() => {
        $('#copyIeltsPrompt').textContent = "✅ Nusxalandi!";
        setTimeout(() => { $('#copyIeltsPrompt').textContent = "📋 Promptni nusxalash"; }, 2000);
      });
    };

    $('#saveIeltsImport').onclick = () => {
      const raw = $('#ieltsPasteArea').value.trim();
      if (!raw) { toast("❌ Avval AI javobini joylashtiring!", "err"); return; }

      try {
        const clean = raw.replace(/```json|```/g, '').trim();
        const parsed = JSON.parse(clean);

        if (!Array.isArray(parsed) || !parsed.length) {
          throw new Error("Bo'sh massiv");
        }

        const timestamp = Date.now();
        let addedCount = 0;

        parsed.forEach((item, idx) => {
          item.id = `usr_${selSection.substring(0, 2)}_${selLevel.toLowerCase()}_${timestamp}_${idx}`;
          item.level = selLevel;

          if (selSection === 'listening') {
            getCustomListening().push(item);
            addedCount++;
          } else if (selSection === 'reading') {
            getCustomReading().push(item);
            addedCount++;
          } else if (selSection === 'speaking') {
            getCustomSpeaking().push(item);
            addedCount++;
          } else if (selSection === 'writing') {
            getCustomWriting().push(item);
            addedCount++;
          }
        });

        save();
        toast(`🎉 ${addedCount} ta yangi IELTS savollari muvaffaqiyatli qo'shildi!`, "gold");
        go('ielts');

      } catch (err) {
        toast("❌ JSON formati xato! Iltimos, qaytadan urinib ko'ring.", "err");
      }
    };
  }

  renderImportView();
});

// ---------------- SETTINGS (With Copy/Paste Text Backup for APK) ----------------
registerRoute('settings', (root) => {
  root.innerHTML = `
    <h1>⚙️ ${esc(t('settingsTitle'))}</h1>
    
    <div class="card">
      <h3>🌐 ${esc(t('language'))}</h3>
      <select id="setLang">
        <option value="uz" ${STATE.settings.lang==='uz'?'selected':''}>O'zbek tili</option>
        <option value="en" ${STATE.settings.lang==='en'?'selected':''}>English</option>
      </select>

      <h3>🎨 ${esc(t('theme'))}</h3>
      <select id="setTheme">
        <option value="dark" ${STATE.settings.theme==='dark'?'selected':''}>${esc(t('dark'))}</option>
        <option value="light" ${STATE.settings.theme==='light'?'selected':''}>${esc(t('light'))}</option>
        <option value="oled" ${STATE.settings.theme==='oled'?'selected':''}>${esc(t('oled'))}</option>
      </select>
    </div>

    <div class="card">
      <div class="switch">
        <span>🔊 ${esc(t('ttsOn'))}</span>
        <div class="toggle ${STATE.settings.tts?'on':''}" id="toggleTts"><i></i></div>
      </div>
      <div class="switch">
        <span>⚡ ${esc(t('autoSpeak'))}</span>
        <div class="toggle ${STATE.settings.autoSpeak?'on':''}" id="toggleAutoSpeak"><i></i></div>
      </div>
      
      <label style="margin-top: 10px;">🏃 ${esc(t('ttsRate'))}: <b id="valRate">${STATE.settings.ttsRate}</b></label>
      <input type="range" id="setRate" min="0.5" max="1.5" step="0.1" value="${STATE.settings.ttsRate}" />

      <label>📳 ${esc(t('vibration'))} (ms): <b id="valVib">${STATE.settings.vibration}</b></label>
      <input type="range" id="setVib" min="0" max="400" step="50" value="${STATE.settings.vibration}" />
    </div>

    <div class="card">
      <label>🎯 ${esc(t('dailyGoalSet'))}</label>
      <input type="number" id="setGoal" value="${STATE.settings.dailyGoal}" />
      
      <div class="row tight">
        <div>
          <label>Easy (kun)</label>
          <input type="number" id="daysEasy" value="${STATE.settings.daysEasy}" />
        </div>
        <div>
          <label>Medium (kun)</label>
          <input type="number" id="daysMedium" value="${STATE.settings.daysMedium}" />
        </div>
        <div>
          <label>Hard (kun)</label>
          <input type="number" id="daysHard" value="${STATE.settings.daysHard}" />
        </div>
      </div>
    </div>

    <!-- Mobil APK-lar uchun nusxalash orqali zaxira tizimi (Custom words + Custom IELTS) -->
    <div class="card">
      <h3>📥 Mobil APK Zaxira tizimi (Matn orqali)</h3>
      <p class="muted" style="font-size: 11px; margin-bottom: 8px;">Dasturdagi barcha qo'shgan so'zlaringiz va IELTS savollaringizni saqlab qolish uchun ushbu kodni nusxalab oling:</p>
      <textarea id="apkBackupText" readonly style="font-size: 10px; min-height: 80px; font-family: monospace; background: rgba(0,0,0,0.1);"></textarea>
      <button class="btn sm" id="copyApkBtn" style="margin-top: 5px;">📋 Kodni nusxalash</button>
      
      <div class="divider"></div>
      <p class="muted" style="font-size: 11px; margin-bottom: 8px;">Saqlab olingan zaxira kodini qayta tiklash uchun shu yerga joylashtiring (Paste):</p>
      <textarea id="apkImportText" placeholder="Zaxira kodini shu yerga joylashtiring..." style="font-size: 10px; min-height: 80px; font-family: monospace;"></textarea>
      <button class="btn sm ok" id="importApkBtn" style="margin-top: 5px; width: 100%;">📥 Zaxirani qayta tiklash</button>
    </div>

    <div class="card">
      <h3>💾 Standart Fayl Zaxirasi</h3>
      <div class="row">
        <button class="btn" id="exportBtn" style="background: var(--ok);">${esc(t('exportData'))}</button>
        <button class="btn" id="importBtn" style="background: var(--pri);">${esc(t('importData'))}</button>
      </div>
      <input type="file" id="fileInput" style="display:none;" accept=".json" />
      <button class="btn err" id="resetBtn" style="margin-top: 10px;">⚠️ ${esc(t('resetData'))}</button>
    </div>
  `;

  const apkArea = $('#apkBackupText');
  if (apkArea) {
    try {
      const stateString = JSON.stringify(STATE);
      apkArea.value = btoa(unescape(encodeURIComponent(stateString)));
    } catch(e) {
      apkArea.value = "Kodni yaratib bo'lmadi.";
    }
  }

  $('#copyApkBtn').onclick = () => {
    apkArea.select();
    document.execCommand('copy');
    toast("📋 Zaxira kodi nusxalandi!", "ok");
  };

  $('#importApkBtn').onclick = () => {
    const rawText = $('#apkImportText').value.trim();
    if (!rawText) { toast("❌ Zaxira kodi kiritilmadi!", "err"); return; }
    try {
      const decoded = decodeURIComponent(escape(atob(rawText)));
      const parsed = JSON.parse(decoded);
      if (parsed && typeof parsed === 'object' && Array.isArray(parsed.words)) {
        STATE = parsed;
        save();
        toast("✅ Ma'lumotlar qayta tiklandi!", "ok");
        setTimeout(() => window.location.reload(), 800);
      } else {
        toast("❌ Zaxira kodi formati xato!", "err");
      }
    } catch (err) {
      toast("❌ Noto'g'ri zaxira kodi!", "err");
    }
  };

  $('#setLang').onchange = (e) => {
    STATE.settings.lang = e.target.value;
    save();
    toast(t('settingsSaved'), 'ok');
    setTimeout(() => go('settings'), 300);
  };

  $('#setTheme').onchange = (e) => {
    const th = e.target.value;
    STATE.settings.theme = th;
    document.documentElement.setAttribute('data-theme', th);
    save();
    toast(t('settingsSaved'), 'ok');
  };

  $('#toggleTts').onclick = () => {
    STATE.settings.tts = !STATE.settings.tts;
    $('#toggleTts').classList.toggle('on', STATE.settings.tts);
    save();
  };
  $('#toggleAutoSpeak').onclick = () => {
    STATE.settings.autoSpeak = !STATE.settings.autoSpeak;
    $('#toggleAutoSpeak').classList.toggle('on', STATE.settings.autoSpeak);
    save();
  };

  $('#setRate').oninput = (e) => {
    STATE.settings.ttsRate = parseFloat(e.target.value);
    $('#valRate').textContent = e.target.value;
    save();
  };
  $('#setVib').oninput = (e) => {
    STATE.settings.vibration = parseInt(e.target.value);
    $('#valVib').textContent = e.target.value;
    save();
  };

  $('#setGoal').onchange = (e) => {
    STATE.settings.dailyGoal = Math.max(1, parseInt(e.target.value) || 10);
    save();
  };
  $('#daysEasy').onchange = (e) => { STATE.settings.daysEasy = Math.max(1, parseInt(e.target.value) || 3); save(); };
  $('#daysMedium').onchange = (e) => { STATE.settings.daysMedium = Math.max(1, parseInt(e.target.value) || 2); save(); };
  $('#daysHard').onchange = (e) => { STATE.settings.daysHard = Math.max(1, parseInt(e.target.value) || 1); save(); };

  $('#exportBtn').onclick = () => {
    try {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(STATE));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", "ielts_passport_backup.json");
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      toast(t('exported'), 'ok');
    } catch (e) {
      toast('Eksport xatoligi!', 'err');
    }
  };

  $('#importBtn').onclick = () => {
    $('#fileInput').click();
  };
  $('#fileInput').onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (parsed && typeof parsed === 'object') {
          STATE = parsed;
          save();
          toast(t('imported'), 'ok');
          setTimeout(() => window.location.reload(), 800);
        } else {
          toast('Fayl formati xato!', 'err');
        }
      } catch (err) {
        toast('JSON o\'qib bo\'lmadi!', 'err');
      }
    };
    reader.readAsText(file);
  };

  $('#resetBtn').onclick = () => {
    if (confirm(t('confirmReset'))) {
      localStorage.clear();
      window.location.reload();
    }
  };
});
