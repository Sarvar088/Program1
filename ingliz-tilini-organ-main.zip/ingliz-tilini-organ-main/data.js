/* ============================================================
   data.js - Seed content (A1 -> C2 IELTS questions & Words)
   ============================================================ */

const SEED_WORDS = [
  // ===== A1 - BEGINNER (diff:1) — 50 ta so'z =====
  {id:'d1',  word:'hello',       tr:"salom",         ex:"Hello, how are you?",              used:"Salomlashish", diff:1},
  {id:'d2',  word:'goodbye',     tr:"xayr",          ex:"Goodbye, see you tomorrow.",       used:"Xayrlashish",  diff:1},
  {id:'d3',  word:'please',      tr:"iltimos",       ex:"Please help me.",                  used:"So'rash",      diff:1},
  {id:'d4',  word:'thank you',   tr:"rahmat",        ex:"Thank you very much.",             used:"Minnatdorlik", diff:1},
  {id:'d5',  word:'water',       tr:"suv",           ex:"I want some water.",               used:"Kundalik",     diff:1},
  {id:'d6',  word:'food',        tr:"ovqat",         ex:"The food is delicious.",           used:"Kundalik",     diff:1},
  {id:'d7',  word:'house',       tr:"uy",            ex:"This is my house.",                used:"Kundalik",     diff:1},
  {id:'d8',  word:'friend',      tr:"do'st",         ex:"He is my best friend.",            used:"Kundalik",     diff:1},
  {id:'d9',  word:'family',      tr:"oila",          ex:"I love my family.",                used:"Kundalik",     diff:1},
  {id:'d10', word:'time',        tr:"vaqt",          ex:"What time is it?",                 used:"Kundalik",     diff:1},
  {id:'d11', word:'day',         tr:"kun",           ex:"Have a nice day.",                 used:"Kundalik",     diff:1},
  {id:'d12', word:'work',        tr:"ish",           ex:"I go to work at eight.",           used:"Kundalik",     diff:1},
  {id:'d13', word:'school',      tr:"maktab",        ex:"My son goes to school.",           used:"Kundalik",     diff:1},
  {id:'d14', word:'money',       tr:"pul",           ex:"I need some money.",               used:"Kundalik",     diff:1},
  {id:'d15', word:'name',        tr:"ism",           ex:"What is your name?",               used:"Tanishish",    diff:1},
  {id:'d16', word:'good',        tr:"yaxshi",        ex:"This is a good book.",             used:"Sifat",        diff:1},
  {id:'d17', word:'bad',         tr:"yomon",         ex:"The weather is bad today.",        used:"Sifat",        diff:1},
  {id:'d18', word:'big',         tr:"katta",         ex:"They live in a big city.",         used:"Sifat",        diff:1},
  {id:'d19', word:'small',       tr:"kichik",        ex:"I have a small car.",              used:"Sifat",        diff:1},
  {id:'d20', word:'hot',         tr:"issiq",         ex:"The tea is hot.",                  used:"Sifat",        diff:1},
  {id:'d21', word:'cold',        tr:"sovuq",         ex:"The water is cold.",               used:"Sifat",        diff:1},
  {id:'d22', word:'yes',         tr:"ha",            ex:"Yes, I understand.",               used:"Javob",        diff:1},
  {id:'d23', word:'no',          tr:"yo'q",          ex:"No, thank you.",                   used:"Javob",        diff:1},
  {id:'d24', word:'book',        tr:"kitob",         ex:"I read a book every day.",         used:"Kundalik",     diff:1},
  {id:'d25', word:'car',         tr:"mashina",       ex:"My car is red.",                   used:"Transport",    diff:1},
  {id:'d26', word:'dog',         tr:"it",            ex:"My dog is very friendly.",         used:"Hayvon",       diff:1},
  {id:'d27', word:'cat',         tr:"mushuk",        ex:"The cat is sleeping.",             used:"Hayvon",       diff:1},
  {id:'d28', word:'man',         tr:"erkak",         ex:"The man is tall.",                 used:"Odam",         diff:1},
  {id:'d29', word:'woman',       tr:"ayol",          ex:"The woman is kind.",               used:"Odam",         diff:1},
  {id:'d30', word:'child',       tr:"bola",          ex:"The child is playing.",            used:"Odam",         diff:1},
  {id:'d31', word:'city',        tr:"shahar",        ex:"I live in a big city.",            used:"Joy",          diff:1},
  {id:'d32', word:'country',     tr:"mamlakat",      ex:"I love my country.",               used:"Joy",          diff:1},
  {id:'d33', word:'eat',         tr:"yemoq",         ex:"I eat lunch at noon.",             used:"Fe'l",         diff:1},
  {id:'d34', word:'drink',       tr:"ichmoq",        ex:"I drink tea every morning.",       used:"Fe'l",         diff:1},
  {id:'d35', word:'go',          tr:"bormoq",        ex:"I go to school by bus.",           used:"Fe'l",         diff:1},
  {id:'d36', word:'come',        tr:"kelmoq",        ex:"Please come here.",                used:"Fe'l",         diff:1},
  {id:'d37', word:'see',         tr:"ko'rmoq",       ex:"I see a beautiful bird.",          used:"Fe'l",         diff:1},
  {id:'d38', word:'want',        tr:"xohlamoq",      ex:"I want to learn English.",         used:"Fe'l",         diff:1},
  {id:'d39', word:'like',        tr:"yoqtirmoq",     ex:"I like football.",                 used:"Fe'l",         diff:1},
  {id:'d40', word:'have',        tr:"ega bo'lmoq",   ex:"I have two sisters.",              used:"Fe'l",         diff:1},
  {id:'d41', word:'mother',      tr:"ona",           ex:"My mother is a teacher.",          used:"Oila",         diff:1},
  {id:'d42', word:'father',      tr:"ota",           ex:"My father works in an office.",    used:"Oila",         diff:1},
  {id:'d43', word:'brother',     tr:"aka/uka",       ex:"My brother is ten years old.",     used:"Oila",         diff:1},
  {id:'d44', word:'sister',      tr:"opa/singil",    ex:"My sister likes music.",           used:"Oila",         diff:1},
  {id:'d45', word:'teacher',     tr:"o'qituvchi",    ex:"My teacher is very kind.",         used:"Kasb",         diff:1},
  {id:'d46', word:'student',     tr:"talaba/o'quvchi",ex:"She is a good student.",         used:"Kasb",         diff:1},
  {id:'d47', word:'happy',       tr:"xursand",       ex:"I am very happy today.",           used:"His",          diff:1},
  {id:'d48', word:'sad',         tr:"xafa",          ex:"He looks sad today.",              used:"His",          diff:1},
  {id:'d49', word:'new',         tr:"yangi",         ex:"I have a new phone.",              used:"Sifat",        diff:1},
  {id:'d50', word:'old',         tr:"eski/katta yoshli", ex:"This is an old building.",    used:"Sifat",        diff:1},

  // ===== A2 - ELEMENTARY (diff:2) — 50 ta so'z =====
  {id:'w1',  word:'achieve',     tr:"erishmoq",      ex:"She worked hard to achieve her goals.", used:"Maqsad", diff:2},
  {id:'w2',  word:'describe',    tr:"tasvirlash",    ex:"Can you describe the picture?",         used:"Nutq",   diff:2},
  {id:'w3',  word:'explain',     tr:"tushuntirmoq",  ex:"Please explain the rules.",             used:"Nutq",   diff:2},
  {id:'w4',  word:'compare',     tr:"solishmoq",     ex:"Compare these two photos.",             used:"Tahlil", diff:2},
  {id:'w5',  word:'benefit',     tr:"foyda",         ex:"Exercise has many health benefits.",    used:"Afzallik",diff:2},
  {id:'w6',  word:'problem',     tr:"muammo",        ex:"We need to solve this problem.",        used:"Kundalik",diff:2},
  {id:'w7',  word:'important',   tr:"muhim",         ex:"It is important to study every day.",   used:"Sifat",   diff:2},
  {id:'w8',  word:'different',   tr:"farqli",        ex:"These two books are very different.",   used:"Sifat",   diff:2},
  {id:'w9',  word:'popular',     tr:"mashhur",       ex:"Football is a popular sport.",          used:"Sifat",   diff:2},
  {id:'w10', word:'dangerous',   tr:"xavfli",        ex:"Driving fast is dangerous.",            used:"Sifat",   diff:2},
  {id:'w11', word:'travel',      tr:"sayohat qilmoq",ex:"I love to travel abroad.",             used:"Fe'l",    diff:2},
  {id:'w12', word:'decide',      tr:"qaror qilmoq",  ex:"She decided to study medicine.",       used:"Fe'l",    diff:2},
  {id:'w13', word:'improve',     tr:"yaxshilash",    ex:"I want to improve my English.",        used:"Fe'l",    diff:2},
  {id:'w14', word:'remember',    tr:"eslamoq",       ex:"Do you remember her name?",            used:"Fe'l",    diff:2},
  {id:'w15', word:'suggest',     tr:"taklif qilmoq", ex:"Can you suggest a good book?",         used:"Fe'l",    diff:2},
  {id:'w16', word:'agree',       tr:"rozilik bildirmoq",ex:"I agree with your idea.",           used:"Fe'l",    diff:2},
  {id:'w17', word:'environment', tr:"atrof-muhit",   ex:"We must protect the environment.",     used:"Mavzu",   diff:2},
  {id:'w18', word:'health',      tr:"salomatlik",    ex:"Health is more important than money.", used:"Mavzu",   diff:2},
  {id:'w19', word:'education',   tr:"ta'lim",        ex:"Education is the key to success.",     used:"Mavzu",   diff:2},
  {id:'w20', word:'technology',  tr:"texnologiya",   ex:"Technology changes our daily life.",   used:"Mavzu",   diff:2},
  {id:'w21', word:'experience',  tr:"tajriba",       ex:"She has a lot of work experience.",    used:"Kasb",    diff:2},
  {id:'w22', word:'opportunity', tr:"imkoniyat",     ex:"This is a great opportunity for you.", used:"Hayot",   diff:2},
  {id:'w23', word:'government',  tr:"hukumat",       ex:"The government built new roads.",      used:"Siyosat", diff:2},
  {id:'w24', word:'society',     tr:"jamiyat",       ex:"We all live in society.",              used:"Ijtimoiy",diff:2},
  {id:'w25', word:'culture',     tr:"madaniyat",     ex:"Every country has its own culture.",   used:"Madaniy", diff:2},
  {id:'w26', word:'increase',    tr:"oshmoq/ko'paytirish",ex:"Prices increased last year.",    used:"Tahlil",  diff:2},
  {id:'w27', word:'reduce',      tr:"kamaytirmoq",   ex:"We should reduce waste.",              used:"Tahlil",  diff:2},
  {id:'w28', word:'develop',     tr:"rivojlantirmoq",ex:"We need to develop new skills.",      used:"Fe'l",    diff:2},
  {id:'w29', word:'provide',     tr:"ta'minlamoq",   ex:"The school provides free lunch.",      used:"Fe'l",    diff:2},
  {id:'w30', word:'require',     tr:"talab qilmoq",  ex:"This job requires good English.",      used:"Fe'l",    diff:2},
  {id:'w31', word:'opinion',     tr:"fikr",          ex:"In my opinion, this is wrong.",        used:"Nutq",    diff:2},
  {id:'w32', word:'reason',      tr:"sabab",         ex:"What is the reason for this?",         used:"Nutq",    diff:2},
  {id:'w33', word:'result',      tr:"natija",        ex:"The result of the exam was good.",     used:"Tahlil",  diff:2},
  {id:'w34', word:'method',      tr:"usul",          ex:"This method works very well.",         used:"Tahlil",  diff:2},
  {id:'w35', word:'example',     tr:"misol",         ex:"For example, dogs are friendly.",      used:"Nutq",    diff:2},
  {id:'w36', word:'communication',tr:"muloqot",      ex:"Good communication is very important.",used:"Hayot",  diff:2},
  {id:'w37', word:'information', tr:"ma'lumot",      ex:"I need more information about this.",  used:"Kundalik",diff:2},
  {id:'w38', word:'relationship', tr:"munosabat",    ex:"They have a good relationship.",       used:"Ijtimoiy",diff:2},
  {id:'w39', word:'successful',  tr:"muvaffaqiyatli",ex:"She is a very successful doctor.",    used:"Sifat",   diff:2},
  {id:'w40', word:'necessary',   tr:"zarur",         ex:"It is necessary to sleep well.",       used:"Sifat",   diff:2},
  {id:'w41', word:'natural',     tr:"tabiiy",        ex:"This food is made with natural ingredients.",used:"Sifat",diff:2},
  {id:'w42', word:'local',       tr:"mahalliy",      ex:"We buy from the local market.",        used:"Sifat",   diff:2},
  {id:'w43', word:'global',      tr:"global, jahon", ex:"Climate change is a global problem.",  used:"Sifat",   diff:2},
  {id:'w44', word:'research',    tr:"tadqiqot",      ex:"Scientists do research every day.",    used:"Fan",     diff:2},
  {id:'w45', word:'produce',     tr:"ishlab chiqarmoq",ex:"This factory produces cars.",       used:"Sanoat",  diff:2},
  {id:'w46', word:'support',     tr:"qo'llab-quvvatlamoq",ex:"Friends support each other.",   used:"Fe'l",    diff:2},
  {id:'w47', word:'consider',    tr:"ko'rib chiqmoq",ex:"Please consider my suggestion.",      used:"Fe'l",    diff:2},
  {id:'w48', word:'cause',       tr:"sabab bo'lmoq", ex:"Pollution causes health problems.",   used:"Fe'l",    diff:2},
  {id:'w49', word:'include',     tr:"o'z ichiga olmoq",ex:"The price includes breakfast.",     used:"Fe'l",    diff:2},
  {id:'w50', word:'choice',      tr:"tanlov",        ex:"You have a choice: tea or coffee?",   used:"Hayot",   diff:2},

  // ===== B1 - INTERMEDIATE (diff:3) — 30 ta so'z =====
  {id:'b1',  word:'significant', tr:"muhim, jiddiy", ex:"There was a significant increase in sales.", used:"Writing", diff:3},
  {id:'b2',  word:'consequence', tr:"oqibat",        ex:"Pollution is a consequence of industry.",   used:"Sabab",   diff:3},
  {id:'b3',  word:'crucial',     tr:"hal qiluvchi",  ex:"Sleep is crucial for good health.",         used:"Muhimlik",diff:3},
  {id:'b4',  word:'analyse',     tr:"tahlil qilmoq", ex:"We need to analyse the data carefully.",    used:"Fan",     diff:3},
  {id:'b5',  word:'evidence',    tr:"dalil",         ex:"There is no evidence for that claim.",      used:"Munozara",diff:3},
  {id:'b6',  word:'influence',   tr:"ta'sir",        ex:"Social media influences young people.",     used:"Ijtimoiy",diff:3},
  {id:'b7',  word:'poverty',     tr:"qashshoqlik",   ex:"Poverty is still a global problem.",        used:"Ijtimoiy",diff:3},
  {id:'b8',  word:'pollution',   tr:"ifloslanish",   ex:"Air pollution harms our health.",           used:"Ekologiya",diff:3},
  {id:'b9',  word:'economy',     tr:"iqtisodiyot",   ex:"The economy grew by five percent.",         used:"Iqtisod", diff:3},
  {id:'b10', word:'policy',      tr:"siyosat/qonun", ex:"The new policy reduced crime rates.",       used:"Siyosat", diff:3},
  {id:'b11', word:'diversity',   tr:"xilma-xillik",  ex:"Diversity makes our society stronger.",     used:"Ijtimoiy",diff:3},
  {id:'b12', word:'sustainable', tr:"barqaror",      ex:"We need sustainable energy sources.",       used:"Ekologiya",diff:3},
  {id:'b13', word:'maintain',    tr:"saqlash",       ex:"It is hard to maintain a healthy diet.",    used:"Fe'l",    diff:3},
  {id:'b14', word:'establish',   tr:"o'rnatmoq",     ex:"They established a new company.",           used:"Fe'l",    diff:3},
  {id:'b15', word:'affect',      tr:"ta'sir qilmoq", ex:"Weather can affect your mood.",             used:"Fe'l",    diff:3},
  {id:'b16', word:'challenge',   tr:"qiyinchilik",   ex:"Learning a new language is a challenge.",  used:"Hayot",   diff:3},
  {id:'b17', word:'attitude',    tr:"munosabat/qarash",ex:"He has a positive attitude to life.",    used:"Xarakter",diff:3},
  {id:'b18', word:'behaviour',   tr:"xulq-atvor",    ex:"Good behaviour is important at school.",   used:"Xarakter",diff:3},
  {id:'b19', word:'resource',    tr:"resurs/manba",  ex:"Water is a precious natural resource.",    used:"Fan",     diff:3},
  {id:'b20', word:'potential',   tr:"imkoniyat/salohiyat",ex:"You have the potential to succeed.", used:"Motivatsiya",diff:3},
  {id:'b21', word:'access',      tr:"kirish/foydalanish",ex:"Everyone should have access to water.",used:"Ijtimoiy",diff:3},
  {id:'b22', word:'community',   tr:"jamoa/mahalla", ex:"We work together as a community.",         used:"Ijtimoiy",diff:3},
  {id:'b23', word:'generation',  tr:"avlod",         ex:"The younger generation loves technology.", used:"Ijtimoiy",diff:3},
  {id:'b24', word:'contribute',  tr:"hissa qo'shmoq",ex:"Everyone can contribute to society.",     used:"Fe'l",    diff:3},
  {id:'b25', word:'identify',    tr:"aniqlash",      ex:"Can you identify the main problem?",       used:"Fe'l",    diff:3},
  {id:'b26', word:'achieve',     tr:"erishmoq",      ex:"Hard work helps you achieve your goals.",  used:"Fe'l",    diff:3},
  {id:'b27', word:'debate',      tr:"munozara",      ex:"There is a debate about climate change.",  used:"Munozara",diff:3},
  {id:'b28', word:'income',      tr:"daromad",       ex:"His income increased this year.",          used:"Iqtisod", diff:3},
  {id:'b29', word:'urban',       tr:"shahar (sifat)",ex:"Urban areas grow faster than rural ones.",used:"Ijtimoiy",diff:3},
  {id:'b30', word:'welfare',     tr:"farovonlik",    ex:"The government cares about public welfare.",used:"Ijtimoiy",diff:3},
];

// ----- MULTI-LEVEL IELTS SEED DATA -----
const SEED_SPEAKING_LEVELS = [
  // A1 (Beginner)
  { id: 'sp_a1_1', level: 'A1', q: "What is your name?", keywords: ["name", "is", "am"], part: 1 },
  { id: 'sp_a1_2', level: 'A1', q: "Where do you live?", keywords: ["live", "in", "tashkent", "uzbekistan"], part: 1 },
  { id: 'sp_a1_3', level: 'A1', q: "How old are you?", keywords: ["years", "old", "am", "is"], part: 1 },
  { id: 'sp_a1_4', level: 'A1', q: "Do you like English?", keywords: ["yes", "like", "english", "love"], part: 1 },
  { id: 'sp_a1_5', level: 'A1', q: "What color is your pen?", keywords: ["blue", "black", "red", "green", "is"], part: 1 },
  
  // A2 (Elementary)
  { id: 'sp_a2_1', level: 'A2', q: "Describe your hometown. What can people do there?", keywords: ["town", "city", "beautiful", "visit", "park", "there is"], part: 1 },
  { id: 'sp_a2_2', level: 'A2', q: "How do you spend your free time?", keywords: ["free time", "usually", "watch", "play", "friends", "hobby"], part: 1 },
  { id: 'sp_a2_3', level: 'A2', q: "Talk about a memorable holiday you had. Where did you go?", keywords: ["went", "travel", "holiday", "hotel", "summer", "beach"], part: 2 },

  // B1 (Intermediate)
  { id: 'sp_b1_1', level: 'B1', q: "Do you prefer studying alone or with friends? Why?", keywords: ["prefer", "because", "focus", "together", "learn", "helpful"], part: 1 },
  { id: 'sp_b1_2', level: 'B1', q: "Describe a public place you like to visit. What does it look like?", keywords: ["location", "atmosphere", "crowded", "relax", "modern", "park"], part: 2 },

  // B2 (Upper-Intermediate)
  { id: 'sp_b2_1', level: 'B2', q: "Some people say newspapers are dying. To what extent do you agree?", keywords: ["media", "digital", "news", "trend", "traditional", "opinion"], part: 3 },

  // C1 (Advanced)
  { id: 'sp_c1_1', level: 'C1', q: "Analyze the socio-economic impacts of globalization on developing nations.", keywords: ["globalization", "economy", "cultural exchange", "exploitation"], part: 3 },

  // C2 (Proficiency)
  { id: 'sp_c2_1', level: 'C2', q: "Expound upon the philosophical assertion that language shapes our cognitive reality.", keywords: ["linguistic relativity", "cognition", "sapir-whorf", "perception"], part: 3 }
];

const SEED_WRITING_LEVELS = [
  // A1 (Beginner)
  { id: 'wr_a1_1', level: 'A1', title: "Introduce Yourself", prompt: "Write about yourself. What is your name, age, and hobby?", minWords: 15, keyPhrases: ["my name", "i am", "i like", "years old"] },
  { id: 'wr_a1_2', level: 'A1', title: "My Family", prompt: "Write about your family. Who do you live with?", minWords: 15, keyPhrases: ["family", "live", "father", "mother", "brother", "sister"] },
  { id: 'wr_a1_3', level: 'A1', title: "My Pet", prompt: "Do you have a pet? What is its name?", minWords: 15, keyPhrases: ["pet", "cat", "dog", "have", "name is"] },
  
  // A2 (Elementary)
  { id: 'wr_a2_1', level: 'A2', title: "My Typical Day", prompt: "Describe your daily routine. What do you do in the morning and evening?", minWords: 30, keyPhrases: ["firstly", "then", "after that", "wake up", "usually"] },
  { id: 'wr_a2_2', level: 'A2', title: "My Last Weekend", prompt: "Write about what you did last weekend. Where did you go?", minWords: 30, keyPhrases: ["last weekend", "went to", "played", "was", "friends"] },

  // B1 (Intermediate)
  { id: 'wr_b1_1', level: 'B1', title: "Healthy Lifestyle", prompt: "What are the benefits of eating healthy food and doing regular exercise?", minWords: 60, keyPhrases: ["in addition", "for example", "healthy", "exercise", "avoid", "important"] },

  // B2 (Upper-Intermediate)
  { id: 'wr_b2_1', level: 'B2', title: "Task 1: Line Graph Overview", prompt: "Paraphrase: The graph displays the rate of carbon emissions from 1990 to 2020.", minWords: 100, keyPhrases: ["illustrates", "overall", "significant increase", "gradual decline"] },

  // C1 (Advanced)
  { id: 'wr_c1_1', level: 'C1', title: "Task 2: Automation", prompt: "Automation causes job loss but increases productivity. Discuss both views.", minWords: 150, keyPhrases: ["nevertheless", "consequently", "productivity", "displacement"] },

  // C2 (Proficiency)
  { id: 'wr_c2_1', level: 'C2', title: "Preservation of Minority Languages", prompt: "Critically evaluate the need for state-funded language preservation.", minWords: 180, keyPhrases: ["linguistic diversity", "homogenization", "cultural heritage"] }
];

const SEED_LISTENING_LEVELS = [
  // A1 (Beginner)
  { id: 'li_a1_1', level: 'A1', text: "I have two dogs and one cat.", q: "How many cats does the speaker have?", a: "one", options: ["one", "two", "three", "none"], keywords: ["one", "1"] },
  { id: 'li_a1_2', level: 'A1', text: "The school starts at eight o'clock.", q: "What time does the school start?", a: "eight", options: ["eight", "nine", "seven", "ten"], keywords: ["eight", "8", "8:00"] },
  { id: 'li_a1_3', level: 'A1', text: "My favorite color is green.", q: "What is the speaker's favorite color?", a: "green", options: ["green", "red", "blue", "yellow"], keywords: ["green"] },
  { id: 'li_a1_4', level: 'A1', text: "I have five red apples.", q: "How many apples does the speaker have?", a: "five", options: ["five", "three", "four", "six"], keywords: ["five", "5"] },
  { id: 'li_a1_5', level: 'A1', text: "I have a new blue school bag.", q: "What color is the school bag?", a: "blue", options: ["blue", "red", "green", "black"], keywords: ["blue"] },
  { id: 'li_a1_6', level: 'A1', text: "I drink cold water every day.", q: "What does the speaker drink?", a: "water", options: ["water", "milk", "juice", "tea"], keywords: ["water"] },

  // A2 (Elementary)
  { id: 'li_a2_1', level: 'A2', text: "We went to a beautiful Italian restaurant yesterday.", q: "What kind of restaurant did they visit?", a: "italian", options: ["italian", "french", "chinese", "mexican"], keywords: ["italian", "italy"] },
  { id: 'li_a2_2', level: 'A2', text: "The flight to Paris costs three hundred dollars.", q: "How much does the ticket to Paris cost?", a: "300", options: ["300", "200", "400", "500"], keywords: ["300", "three hundred"] },
  { id: 'li_a2_3', level: 'A2', text: "Our family walks in the garden every Sunday evening.", q: "When does the family walk in the garden?", a: "sunday", options: ["sunday", "saturday", "friday", "monday"], keywords: ["sunday", "on sunday"] },
  { id: 'li_a2_4', level: 'A2', text: "My brother got a new white phone for his birthday.", q: "What color is the brother's new phone?", a: "white", options: ["white", "black", "gold", "silver"], keywords: ["white"] },
  { id: 'li_a2_5', level: 'A2', text: "I am going to buy six yellow bananas from the supermarket.", q: "How many bananas is the speaker going to buy?", a: "six", options: ["six", "five", "four", "eight"], keywords: ["six", "6"] },
  { id: 'li_a2_6', level: 'A2', text: "The train arrives at platforms three and four.", q: "Which platforms does the train arrive at?", a: "three", options: ["three", "one", "five", "two"], keywords: ["three", "3"] },

  // B1 (Intermediate)
  { id: 'li_b1_1', level: 'B1', text: "The business meeting has been rescheduled to Friday afternoon due to the bad weather.", q: "On which day will the meeting be held?", a: "friday", options: ["friday", "monday", "wednesday", "thursday"], keywords: ["friday"] },
  { id: 'li_b1_2', level: 'B1', text: "If you want to stay fit, you must avoid sugary drinks and exercise daily.", q: "What should you avoid according to the speaker?", "a": "drinks", options: ["drinks", "exercise", "vegetables", "fruits"], keywords: ["drinks", "sugary drinks"] },
  { id: 'li_b1_3', level: 'B1', text: "I bought this leather jacket from a vintage shop for fifty dollars.", q: "How much did the leather jacket cost?", "a": "50", options: ["50", "40", "60", "100"], keywords: ["50", "fifty", "fifty dollars"] },
  { id: 'li_b1_4', level: 'B1', text: "The company decided to hire a new marketing manager next month.", q: "Which position is the company going to fill next month?", "a": "manager", options: ["manager", "accountant", "director", "designer"], keywords: ["manager", "marketing manager"] },
  { id: 'li_b1_5', level: 'B1', text: "You can pick up your passport from the embassy next Tuesday.", q: "When can you pick up your passport?", "a": "tuesday", options: ["tuesday", "monday", "thursday", "wednesday"], keywords: ["tuesday", "next tuesday"] },
  { id: 'li_b1_6', level: 'B1', text: "The museum is completely free of charge on the first weekend of every month.", q: "When is the museum free to visit?", "a": "weekend", options: ["weekend", "tuesday", "friday", "monday"], keywords: ["weekend", "first weekend"] },

  // B2 (Upper-Intermediate)
  { id: 'li_b2_1', level: 'B2', text: "Many rare animal species went extinct primarily because of rapid habitat destruction.", q: "What was the main cause of extinction mentioned?", a: "destruction", options: ["destruction", "hunting", "pollution", "storms"], keywords: ["destruction", "habitat destruction"] },
  { id: 'li_b2_2', level: 'B2', text: "The seminar on cyber security will take place in lecture hall seven next week.", q: "Where will the cyber security seminar take place?", "a": "seven", options: ["seven", "three", "five", "eight"], keywords: ["seven", "7", "hall seven"] },
  { id: 'li_b2_3', level: 'B2', text: "Global temperatures are predicted to rise by another two degrees by 2050.", q: "How many degrees are temperatures predicted to rise?", "a": "two", options: ["two", "three", "one", "five"], keywords: ["two", "2", "two degrees"] },
  { id: 'li_b2_4', level: 'B2', text: "The customer service hotline is available twenty-four hours a day, seven days a week.", q: "How long is the customer service hotline available?", "a": "always", options: ["always", "daytime", "weekdays", "office hours"], keywords: ["always", "24/7", "all the time"] },
  { id: 'li_b2_5', level: 'B2', text: "We need to install high-quality insulation to reduce energy consumption in this building.", q: "What must be installed to reduce energy consumption?", "a": "insulation", options: ["insulation", "solar panels", "heaters", "double glazing"], keywords: ["insulation"] },
  { id: 'li_b2_6', level: 'B2', text: "The research shows that a high percentage of online purchases are made on mobile devices.", q: "Where are a high percentage of online purchases made?", "a": "mobile", options: ["mobile", "computers", "tablets", "tv"], keywords: ["mobile", "mobile devices", "phones"] },

  // C1 (Advanced)
  { id: 'li_c1_1', level: 'C1', text: "The fiscal deficit has surged inadvertently, necessitating an immediate budget revision.", q: "What urgent measure must be taken due to the deficit?", a: "revision", options: ["revision", "taxes", "loans", "inflation"], keywords: ["revision", "budget revision"] },
  { id: 'li_c1_2', level: 'C1', text: "The brain's cognitive agility declines slightly with age, but creative capacity often remains intact.", q: "What remains intact despite cognitive decline with age?", "a": "creativity", options: ["creativity", "agility", "memory", "speed"], keywords: ["creativity", "creative capacity"] },
  { id: 'li_c1_3', level: 'C1', text: "The implementation of the new tariff system is scheduled for the first quarter of next fiscal year.", q: "When is the implementation of the new tariff system scheduled?", "a": "quarter", options: ["quarter", "month", "week", "year"], keywords: ["quarter", "first quarter"] },
  { id: 'li_c1_4', level: 'C1', text: "Our university offers specialized scholarships for students conducting renewable energy research.", q: "For what research field does the university offer specialized scholarships?", "a": "energy", options: ["energy", "medicine", "ai", "physics"], keywords: ["energy", "renewable energy"] },
  { id: 'li_c1_5', level: 'C1', text: "Water scarcity is becoming a critical geopolitical issue in several arid regions.", q: "What type of issue is water scarcity becoming?", "a": "geopolitical", options: ["geopolitical", "economic", "social", "climatic"], keywords: ["geopolitical"] },
  { id: 'li_c1_6', level: 'C1', text: "The urban planning committee approved the development of three new ecological parks in downtown areas.", q: "What did the urban planning committee approve?", "a": "parks", options: ["parks", "roads", "buildings", "bridges"], keywords: ["parks", "ecological parks"] },

  // C2 (Proficiency)
  { id: 'li_c2_1', level: 'C2', text: "The sheer ubiquity of consumerist ideals compromises traditional cultural paradigms.", q: "What compromises the preservation of traditional cultures?", a: "ideals", options: ["ideals", "laws", "climate", "technology"], keywords: ["ideals", "consumerist ideals"] },
  { id: 'li_c2_2', level: 'C2', text: "Epistemological frameworks dictate how we interpret sensory experiences and construct empirical claims.", q: "What dictates how we interpret sensory experiences?", "a": "frameworks", options: ["frameworks", "senses", "genes", "feelings"], keywords: ["frameworks", "epistemological frameworks"] },
  { id: 'li_c2_3', level: 'C2', text: "The hypothetical existence of a graviton particle remains a central pursuit in quantum gravity.", q: "What particle remains a central pursuit in quantum gravity research?", "a": "graviton", options: ["graviton", "boson", "electron", "proton"], keywords: ["graviton"] },
  { id: 'li_c2_4', level: 'C2', text: "Linguistic relativity suggests that the structure of a language influences its speakers' cognition.", q: "What does language structure influence according to linguistic relativity?", "a": "cognition", options: ["cognition", "pronunciation", "vocabulary", "accent"], keywords: ["cognition", "speakers' cognition"] },
  { id: 'li_c2_5', level: 'C2', text: "The convergence of deep neural networks and biometric sensors is transforming healthcare diagnostics.", q: "What is transforming healthcare diagnostics besides biometric sensors?", "a": "networks", options: ["networks", "drugs", "hospitals", "surgery"], keywords: ["networks", "deep neural networks"] },
  { id: 'li_c2_6', level: 'C2', text: "Nash equilibrium defines a state of mutual optimal response, precluding unilateral deviations.", q: "What does Nash equilibrium preclude?", "a": "deviations", options: ["deviations", "cooperation", "competition", "negotiations"], keywords: ["deviations", "unilateral deviations"] }
];

const SEED_READING_LEVELS = [
  // A1 (Beginner)
  { id: 're_a1_1', level: 'A1', title: "My Small Room", text: "My room is small. It has a single bed, a black desk, and a red chair. I love my room.", q: "What color is the chair?", a: "red", options: ["red", "black", "blue", "green"], keywords: ["red", "red chair"] },
  { id: 're_a1_2', level: 'A1', title: "The Family Farm", text: "My grandfather has a farm. There are five cows, two dogs, and a small horse on the farm.", q: "How many cows are on the farm?", a: "five", options: ["five", "two", "one", "three"], keywords: ["five", "5"] },
  { id: 're_a1_3', level: 'A1', title: "My Blue Bag", text: "I have a new school bag. The school bag is blue. It has three books and two pens inside.", q: "What color is the school bag?", a: "blue", options: ["blue", "red", "yellow", "black"], keywords: ["blue", "blue bag"] },
  { id: 're_a1_4', level: 'A1', title: "My Pet Kitty", text: "I have a pet cat. Its name is Kitty. Kitty likes to drink fresh white milk every morning.", q: "What does Kitty like to drink?", a: "milk", options: ["milk", "water", "juice", "tea"], keywords: ["milk", "fresh milk"] },
  { id: 're_a1_5', level: 'A1', title: "The Red Apples", text: "There is a big tree in our garden. It has sweet red apples. My sister eats two apples every day.", q: "What color are the apples?", a: "red", options: ["red", "green", "yellow", "orange"], keywords: ["red", "red apples"] },
  { id: 're_a1_6', level: 'A1', title: "A Sunny Day", text: "Today is a warm sunny day. The sky is bright blue and there are no clouds. We want to play outside.", q: "What color is the sky today?", a: "blue", options: ["blue", "grey", "white", "black"], keywords: ["blue", "bright blue"] },
  
  // A2 (Elementary)
  { id: 're_a2_1', level: 'A2', title: "Weekly Market", text: "Every Saturday morning, a local market opens in our village. Farmers bring fresh vegetables, fruits, and organic honey. It is cheaper than the supermarket.", q: "On which day of the week does the market open?", a: "saturday", options: ["saturday", "sunday", "friday", "monday"], keywords: ["saturday", "on saturday"] },
  { id: 're_a2_2', level: 'A2', title: "A Trip to London", text: "Last summer, Alice visited London. She saw the Big Ben, rode a red double-decker bus, and visited the British Museum. She stayed there for five days.", q: "How many days did Alice stay in London?", a: "five", options: ["five", "three", "seven", "ten"], keywords: ["five", "5", "five days"] },
  { id: 're_a2_3', level: 'A2', title: "Cooking Dinner", text: "David loves cooking. Tonight, he is making a delicious chicken pasta for his family. He needs cheese, tomatoes, and some garlic.", q: "What is David making for dinner tonight?", a: "pasta", options: ["pasta", "pizza", "soup", "salad"], keywords: ["pasta", "chicken pasta"] },
  { id: 're_a2_4', level: 'A2', title: "The Library", text: "The city library is a very quiet place. It is open from nine in the morning until eight at night. It has more than ten thousand books.", q: "What time does the library close at night?", a: "eight", options: ["eight", "nine", "seven", "six"], keywords: ["eight", "8", "8 pm"] },
  { id: 're_a2_5', level: 'A2', title: "My Favorite Sport", text: "Sarah is a great swimmer. She goes to the local swimming pool three times a week. She started swimming when she was only seven years old.", q: "How many times a week does Sarah go swimming?", a: "three", options: ["three", "two", "four", "five"], keywords: ["three", "3", "three times"] },
  { id: 're_a2_6', level: 'A2', title: "Healthy Breakfast", text: "Eating breakfast is very important. Emma always eats a bowl of oatmeal with fresh bananas and drinks a glass of orange juice before school.", q: "What does Emma drink for breakfast?", a: "juice", options: ["juice", "milk", "coffee", "water"], keywords: ["juice", "orange juice"] },

  // B1 (Intermediate)
  { id: 're_b1_1', level: 'B1', title: "The Power of Sleep", text: "Scientific research suggests that adults require at least seven to eight hours of sleep per night. Lack of sleep weakens the immune system and reduces focus.", q: "What is the minimum number of hours of sleep adults need?", a: "seven", options: ["seven", "eight", "six", "nine"], keywords: ["seven", "7", "seven hours"] },
  { id: 're_b1_2', level: 'B1', title: "E-Learning Benefits", text: "Online education has grown rapidly. It allows students to learn at their own pace from anywhere in the world. However, it requires self-discipline to succeed.", q: "What is a key requirement for succeeding in online learning?", a: "discipline", options: ["discipline", "money", "fast internet", "smartphones"], keywords: ["discipline", "self-discipline", "self discipline"] },
  { id: 're_b1_3', level: 'B1', title: "The Amazon Rainforest", text: "The Amazon is the world's largest tropical rainforest. It produces roughly twenty percent of the Earth's oxygen and is home to millions of animal species.", q: "What percentage of the Earth's oxygen does the Amazon produce?", a: "twenty", options: ["twenty", "ten", "thirty", "fifty"], keywords: ["twenty", "20", "20 percent", "twenty percent"] },
  { id: 're_b1_4', level: 'B1', title: "History of Coffee", text: "Coffee was first discovered in Ethiopia in the ninth century. A goat herder noticed his goats became very energetic after eating berries from a certain tree.", q: "In which country was coffee originally discovered?", a: "ethiopia", options: ["ethiopia", "yemen", "brazil", "colombia"], keywords: ["ethiopia"] },
  { id: 're_b1_5', level: 'B1', title: "Smart Cities", text: "Many cities are using technology to improve life. Sensors collect data to manage traffic, reduce energy usage, and keep streets clean. This is called a smart city.", q: "What do smart cities use to collect data?", a: "sensors", options: ["sensors", "cameras", "satellites", "police"], keywords: ["sensors"] },
  { id: 're_b1_6', level: 'B1', title: "Plastic Pollution", text: "Millions of tons of plastic waste enter the oceans each year. Marine animals mistake plastic for food, which causes severe harm to the sea ecosystem.", q: "What do marine animals mistake plastic for?", a: "food", options: ["food", "toys", "fish", "plants"], keywords: ["food", "their food"] },

  // B2 (Upper-Intermediate)
  { id: 're_b2_1', level: 'B2', title: "Renewable Energy Transition", text: "The transition to renewable energy sources is accelerating globally. While the initial investment remains substantial, long-term environmental benefits outweigh the costs.", q: "What is a major obstacle to the renewable transition?", a: "investment", options: ["investment", "sunlight", "space", "weather"], keywords: ["investment", "initial investment"] },
  { id: 're_b2_2', level: 'B2', title: "The Invention of Printing", text: "Johannes Gutenberg invented the printing press in the fifteenth century. This invention allowed books to be mass-produced, leading to a massive increase in literacy rates.", q: "In which century was the printing press invented?", a: "fifteenth", options: ["fifteenth", "fourteenth", "sixteenth", "seventeenth"], keywords: ["fifteenth", "15th"] },
  { id: 're_b2_3', level: 'B2', title: "The Great Barrier Reef", text: "The Great Barrier Reef is experiencing severe coral bleaching. Marine biologists warn that rising water temperatures, driven by global warming, are the primary cause of this phenomenon.", q: "What is the main cause of coral bleaching?", a: "temperatures", options: ["temperatures", "fishing", "pollution", "storms"], keywords: ["temperatures", "water temperatures", "rising water temperatures"] },
  { id: 're_b2_4', level: 'B2', title: "Artificial Intelligence Evolution", text: "Modern artificial intelligence systems rely heavily on machine learning algorithms. These algorithms require large datasets to train effectively and make accurate predictions.", q: "What do machine learning algorithms need to train effectively?", a: "datasets", options: ["datasets", "electricity", "screens", "keyboards"], keywords: ["datasets", "large datasets"] },
  { id: 're_b2_5', level: 'B2', title: "Deep Sea Exploration", text: "Exploring the deepest parts of the ocean is extremely challenging. High hydrostatic pressure and total darkness make it difficult for scientists to operate deep-sea submersibles.", q: "What makes deep ocean exploration difficult besides darkness?", a: "pressure", options: ["pressure", "waves", "sharks", "temperature"], keywords: ["pressure", "hydrostatic pressure"] },
  { id: 're_b2_6', level: 'B2', title: "The Rise of E-Books", text: "E-books have transformed the publishing industry. While they significantly reduce paper consumption, some readers report experiencing digital eye strain after long hours of reading.", q: "What is a common complaint from people reading e-books?", a: "strain", options: ["strain", "cost", "weight", "storage"], keywords: ["strain", "eye strain", "digital eye strain"] },

  // C1 (Advanced)
  { id: 're_c1_1', level: 'C1', title: "Cognitive Psychology and Bias", text: "Implicit bias refers to the unconscious attributions we make to social groups. These automatic processes operate silently, altering behavior without our explicit awareness.", q: "How do implicit biases operate in our minds according to the text?", a: "unconsciously", options: ["unconsciously", "deliberately", "rarely", "logically"], keywords: ["unconsciously", "unconscious"] },
  { id: 're_c1_2', level: 'C1', title: "The Economics of Inflation", text: "When inflation surges, central banks often raise benchmark interest rates. This monetary tightening aims to reduce consumer spending and stabilize commodity prices.", q: "What action do central banks take to curb rising inflation?", a: "rates", options: ["rates", "spend", "print money", "reduce taxes"], keywords: ["rates", "interest rates", "raise interest rates"] },
  { id: 're_c1_3', level: 'C1', title: "Architectural Evolution", text: "The development of load-bearing steel frames in the late nineteenth century revolutionized architecture. It allowed builders to construct tall skyscrapers instead of low stone buildings.", q: "What technological development enabled the construction of skyscrapers?", a: "frames", options: ["frames", "concrete", "elevators", "glass"], keywords: ["frames", "steel frames", "load-bearing steel frames"] },
  { id: 're_c1_4', level: 'C1', title: "Astrophysics and Dark Matter", text: "Dark matter is a hypothetical form of matter that is invisible to telescopes. It does not emit or absorb light, but scientists can detect its presence through its gravitational effects.", q: "How do scientists detect the presence of dark matter?", a: "gravitational", options: ["gravitational", "telescopes", "radiation", "heat"], keywords: ["gravitational", "gravity", "gravitational effects"] },
  { id: 're_c1_5', level: 'C1', title: "Neuroplasticity Explained", text: "Neuroplasticity refers to the brain's lifelong ability to reorganize itself by forming new neural connections in response to learning, experience, or physical injury.", q: "What is the brain's ability to reorganize itself called?", a: "neuroplasticity", options: ["neuroplasticity", "neurogenesis", "memory", "cognition"], keywords: ["neuroplasticity"] },
  { id: 're_c1_6', level: 'C1', title: "Microclimates in Cities", text: "Urban heat islands are microclimates where city centers are significantly warmer than surrounding rural areas. This is primarily caused by dark concrete surfaces absorbing solar radiation.", q: "What is the main cause of the urban heat island effect?", a: "concrete", options: ["concrete", "cars", "air conditioners", "population"], keywords: ["concrete", "dark concrete", "concrete surfaces"] },

  // C2 (Proficiency)
  { id: 're_c2_1', level: 'C2', title: "Quantum Computing Paradigm", text: "Quantum superposition allows qubits to perform complex multi-state computations concurrently, potentially rendering modern RSA encryption techniques entirely obsolete.", q: "What quantum phenomenon allows qubits to compute multiple states at once?", a: "superposition", options: ["superposition", "entanglement", "decoherence", "tunneling"], keywords: ["superposition", "quantum superposition"] },
  { id: 're_c2_2', level: 'C2', title: "Epistemological Skepticism", text: "Descartes utilized methodical doubt to challenge all empirical assertions. By stripping away doubtful assumptions, he sought to establish an indubitable foundation for human knowledge.", q: "What was the primary objective of Descartes' methodical doubt?", a: "certainty", options: ["certainty", "confusion", "atheism", "empiricism"], keywords: ["certainty", "foundation", "indubitable foundation"] },
  { id: 're_c2_3', level: 'C2', title: "Syntactic Structures Theory", text: "Noam Chomsky argued that human language acquisition is driven by an innate, universal grammar template embedded in our cognitive biology, rather than purely behavioral mimicry.", q: "What did Chomsky suggest is responsible for human language acquisition?", a: "grammar", options: ["grammar", "mimicry", "education", "culture"], keywords: ["grammar", "universal grammar", "innate grammar"] },
  { id: 're_c2_4', level: 'C2', title: "The Anthropocene Epoch", text: "The term Anthropocene designates a geological epoch defined by global human impact. The primary stratigraphical marker is the presence of radioactive isotopes from twentieth-century atomic testing.", q: "What is the main stratigraphical marker designating the Anthropocene?", a: "isotopes", options: ["isotopes", "carbon", "fossils", "plastics"], keywords: ["isotopes", "radioactive isotopes"] },
  { id: 're_c2_5', level: 'C2', title: "Symbiotic Mycorrhizal Networks", text: "Mycorrhizal networks facilitate subterranean nutrient and chemical signal transfers between plants. These complex fungal webs allow trees to share vital resources and warn of pests.", q: "What facilitates subterranean resource sharing between trees?", a: "networks", options: ["networks", "roots", "soil", "water"], keywords: ["networks", "mycorrhizal networks", "fungal webs"] },
  { id: 're_c2_6', level: 'C2', title: "Algorithmic Game Theory", text: "Nash equilibrium predicts stable strategies in complex multi-agent environments. It defines a state where no player has any incentive to deviate unilaterally from their selected strategy.", q: "What equilibrium state is used to predict stable strategies in multi-agent systems?", a: "nash", options: ["nash", "pareto", "markov", "fourier"], keywords: ["nash", "nash equilibrium"] }
];

// Eski seedlar bilan moslikni saqlab qolish uchun o'zgaruvchilar
const SEED_SPEAKING = {
  parts: [{part:1, title:"Part 1 - Introduction", questions:["Do you work or are you a student?"]}],
  formulas: ["In my view..."],
  phrases: ["To be honest, ..."]
};
const SEED_WRITING = {
  task1: { title: "Task 1", structure: ["Intro"], formulas: ["The graph illustrates"] },
  task2: { title: "Task 2", structure: ["Intro"], formulas: ["In conclusion"] },
  linking: ["however", "moreover", "furthermore"]
};
const SEED_LISTENING = [{text: "Hello", q: "Hello?", a: "hello"}];
const SEED_READING = [{title: "World", text: "Hello world", q: "Hello?", a: "world"}];

const CEFR_LEVELS = [
  {id:'A1', name:'Beginner',           minPts:0,    ielts:'0-2.5', icon:'🌱', color:'#27c498'},
  {id:'A2', name:'Elementary',          minPts:200,  ielts:'3.0-3.5', icon:'🌿', color:'#4dd8a8'},
  {id:'B1', name:'Intermediate',        minPts:600,  ielts:'4.0-5.0', icon:'💪', color:'#ffb020'},
  {id:'B2', name:'Upper-Intermediate',  minPts:1500, ielts:'5.5-6.5', icon:'🔥', color:'#ff8c20'},
  {id:'C1', name:'Advanced',            minPts:3500, ielts:'7.0-8.0', icon:'⚡', color:'#9b8cff'},
  {id:'C2', name:'Proficiency',         minPts:7000, ielts:'8.5-9.0', icon:'👑', color:'#ffd54a'}
];

const DIFF_MULTIPLIER = {1: 1, 2: 1.5, 3: 2.5, 4: 3.5, 5: 5};

const SHOP_ITEMS = [
  {id:'s1', name:'Sirli sitata', price:30, cefrMin:'A1', icon:'🌅', type:'mystery', reveal:'quote', reward:'💬 "Muvaffaqiyatning siri — boshlashdir."\n— Mark Twain\n\n"The secret of getting ahead is getting started."'},
  {id:'s2', name:'Birinchi medal', price:50, cefrMin:'A1', icon:'🏅', type:'badge', reward:'🏅 Tabriklaymiz! Birinchi medalingizni qo\'lga kiritdingiz!'},
  {id:'s3', name:'+20 XP bonus', price:40, cefrMin:'A1', icon:'⚡', type:'bonus_xp', bonusXp:20, reward:'⚡ +20 XP hisobingizga qo\'shildi!\nDavom eting, har bir so\'z sizni oldinga olib boradi!'},
  {id:'s4', name:'Sirli quti', price:120, cefrMin:'A2', icon:'📦', type:'mystery', reveal:'idiom', reward:'"Break a leg!" = Omad tilayman! 🎭\nSahna odamlari shunday der.\n"Good luck" o\'rniga ishlatiladi!'},
  {id:'s5', name:'Streak himoyachi', price:100, cefrMin:'A2', icon:'🛡️', type:'streak_shield', reward:'🛡️ 1 kunlik streak himoyachisi! Zanjir uzilmaydi.'},
  {id:'s6', name:'Sirli kalit', price:150, cefrMin:'A2', icon:'🗝️', type:'mystery', reveal:'fact', reward:'🧠 Qiziq fakt:\nIngliz tilida eng ko\'p ishlatiladigan harf — "E" (12.7%)!'},
  {id:'s7', name:'IELTS yashirin sir', price:300, cefrMin:'B1', icon:'🎓', type:'mystery', reveal:'tip', reward:'✍️ IELTS Writing siri:\n"Furthermore" va "Moreover" so\'zlarini ko\'proq ishlating.'},
  {id:'s8', name:'+80 XP paketi', price:350, cefrMin:'B1', icon:'🔋', type:'bonus_xp', bonusXp:80, reward:'🔋 +80 XP hisobingizga qo\'shildi!'},
  {id:'s9', name:'Oltin avatar', price:400, cefrMin:'B1', icon:'🖼️', type:'avatar', reward:'🌟 Oltin avatar! B1 darajasiga yetdingiz.'},
  {id:'s10', name:'C1 yo\'l xaritasi', price:800, cefrMin:'B2', icon:'🗺️', type:'mystery', reveal:'tip', reward:'🗺️ C1 yo\'l xaritasi:\nHar kuni 30 daqiqa reading + 20 daqiqa listening qiling.'},
  {id:'s11', name:'+200 XP jackpot', price:700, cefrMin:'B2', icon:'💎', type:'bonus_xp', bonusXp:200, reward:'💎 +200 XP jackpot!'},
  {id:'s12', name:'Brilliant nishon', price:900, cefrMin:'B2', icon:'💠', type:'badge', reward:'💠 Brilliant nishon!'},
  {id:'s13', name:'Native speaker siri', price:2000, cefrMin:'C1', icon:'🎤', type:'mystery', reveal:'fact', reward:'🎤 Native speaker siri:\n"gonna/wanna"dan og\'zaki nutqda foydalaning, inshoda esa yo\'q.'},
  {id:'s14', name:'Oltin toj', price:2500, cefrMin:'C1', icon:'👑', type:'badge', reward:'👑 Oltin toj! Advanced darajaga yetdingiz.'},
  {id:'s15', name:'Legenda', price:5000, cefrMin:'C2', icon:'🏆', type:'badge', reward:'🏆 LEGENDA! C2 darajasiga yetdingiz.'}
];

const ACHIEVEMENTS = [
  {id:'first',   icon:'🌱', check:s=>s.totalLearned>=1},
  {id:'ten',     icon:'🔟', check:s=>s.totalLearned>=10},
  {id:'fifty',   icon:'💪', check:s=>s.totalLearned>=50},
  {id:'hundred', icon:'🏅', check:s=>s.totalLearned>=100},
  {id:'streak3', icon:'🔥', check:s=>s.streak>=3},
  {id:'streak7', icon:'⚡', check:s=>s.streak>=7},
  {id:'streak30',icon:'👑', check:s=>s.streak>=30},
  {id:'points100',icon:'💎', check:s=>s.points>=100},
  {id:'points500',icon:'🌟', check:s=>s.points>=500},
  {id:'level5',  icon:'🚀', check:s=>s.level>=5},
  {id:'speaker', icon:'🎤', check:s=>s.spokeOnce},
  {id:'writer',  icon:'✍️', check:s=>s.wroteOnce},
  {id:'twentyfive',icon:'🌟', check:s=>s.totalLearned>=25},
  {id:'seventyfive',icon:'📚', check:s=>s.totalLearned>=75},
  {id:'twohundred',icon:'🎓', check:s=>s.totalLearned>=200},
  {id:'fivehundred',icon:'🧠', check:s=>s.totalLearned>=500},
  {id:'thousand',icon:'👑', check:s=>s.totalLearned>=1000},
  {id:'streak14',icon:'🔥', check:s=>s.streak>=14},
  {id:'streak60',icon:'☄️', check:s=>s.streak>=60},
  {id:'streak100',icon:'🏆', check:s=>s.streak>=100},
  {id:'level10', icon:'🛸', check:s=>s.level>=10},
  {id:'level20', icon:'🌈', check:s=>s.level>=20},
  {id:'points1000',icon:'💰', check:s=>s.points>=1000},
  {id:'points5000',icon:'💎', check:s=>s.points>=5000},
  {id:'cefrA2', icon:'🌿', check:s=>s.points>=200},
  {id:'cefrB1', icon:'💪', check:s=>s.points>=600},
  {id:'cefrB2', icon:'🔥', check:s=>s.points>=1500},
  {id:'cefrC1', icon:'⚡', check:s=>s.points>=3500},
  {id:'cefrC2', icon:'👑', check:s=>s.points>=7000}
];

function getCefrLevel(pts) {
  let lvl = CEFR_LEVELS[0];
  for (let i = CEFR_LEVELS.length - 1; i >= 0; i--) {
    const c = CEFR_LEVELS[i];
    if (pts >= c.minPts) {
      if (i === 0) { lvl = c; break; }
      const prevId = CEFR_LEVELS[i - 1].id;
      if (typeof STATE !== 'undefined' && typeof passportProgress === 'function') {
        const prog = passportProgress(prevId);
        const done = prog && prog.total >= 100;
        if (done) { lvl = c; break; }
        lvl = CEFR_LEVELS[i - 1];
        break;
      } else {
        lvl = c; break;
      }
    }
  }
  return lvl;
}

function getNextCefr(pts) {
  for (let i = 0; i < CEFR_LEVELS.length; i++) {
    if (pts < CEFR_LEVELS[i].minPts) return CEFR_LEVELS[i];
  }
  return null;
}

function cefrProgress(pts) {
  const cur = getCefrLevel(pts);
  const nxt = getNextCefr(pts);
  if (!nxt) return 100;
  return Math.round((pts - cur.minPts) / (nxt.minPts - cur.minPts) * 100);
}