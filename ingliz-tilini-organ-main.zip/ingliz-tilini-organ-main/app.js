/* ============================================================
   app.js - Core application logic (Part A)
   State, persistence, scoring/gamification, TTS, vibration,
   router, Home, Vocabulary, Practice (SRS + drag&drop).
   IELTS sections + Settings live in app-ielts.js (Part B).
   ============================================================ */
'use strict';

/* ---------------- Persistence ---------------- */
const STORE_KEY = 'ielts_app_state_v1';

const DEFAULT_SETTINGS = {
  lang: 'uz',
  theme: 'dark',
  tts: true,
  autoSpeak: true,
  ttsRate: 0.9,
  ttsVoice: '',          // empty = auto (prefer en-GB/en-US)
  vibration: 200,        // ms strength
  dailyGoal: 10,
  // SRS intervals (days) - configurable
  daysEasy: 3, daysMedium: 2, daysHard: 1, daysWrong: 1
};

function freshState() {
  return {
    settings: { ...DEFAULT_SETTINGS },
    words: SEED_WORDS.map(w => ({
      ...w,
      // diff: 1=beginner, 2=intermediate, 3=advanced. Default 2 if missing.
      diff: w.diff || 2,
      box: 0,            // SRS box / streak of correct answers
      due: 0,            // next review timestamp (ms); 0 = due now
      seen: 0,           // times reviewed
      learned: false
    })),
    points: 0,
    xp: 0,
    level: 1,
    streak: 0,
    lastStudyDay: '',    // YYYY-MM-DD
    todayCount: 0,
    todayDay: '',
    unlocked: [],        // achievement ids
    spokeOnce: false,
    wroteOnce: false,
    // User-added IELTS content (merged with the SEED_* defaults at render time)
    customReading: [],   // {title, text, q, a}
    customListening: [], // {text, q, a}
    customSpeaking: [],  // {part, title, questions:[...]}
    purchased: [],       // sotib olingan sovg'alar
    // CEFR Passport: har daraja uchun bajarilgan mashqlar soni
    passport: {} // {A1:{vocab:0,quiz:0,speak:0,write:0,read:0}, A2:{...}}
  };
}

let STATE = load();

function load() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return freshState();
    const s = JSON.parse(raw);
    s.settings = { ...DEFAULT_SETTINGS, ...(s.settings || {}) };
    if (!Array.isArray(s.words)) s.words = freshState().words;
    // Backfill new custom-content arrays for users upgrading from old versions.
    if (!Array.isArray(s.customReading)) s.customReading = [];
    if (!Array.isArray(s.customListening)) s.customListening = [];
    if (!Array.isArray(s.customSpeaking)) s.customSpeaking = [];
    if (!Array.isArray(s.purchased)) s.purchased = [];
    return s;
  } catch (e) { return freshState(); }
}

/* Debounced save - prevents localStorage thrashing when many events fire fast
   (e.g. rapid quiz answers, drag-drop sessions). */
let _saveTimer = 0;
function save() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(_saveNow, 120);
}
function _saveNow() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(STATE)); } catch (e) {}
}
/* Force immediate save (used before page unload). */
function saveImmediate() { clearTimeout(_saveTimer); _saveNow(); }
window.addEventListener('beforeunload', saveImmediate);
window.addEventListener('pagehide', saveImmediate);

/* ---------------- Helpers ---------------- */
const $  = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const now = () => Date.now();
const DAY = 24 * 60 * 60 * 1000;
const todayStr = () => new Date().toISOString().slice(0, 10);
function t(key) {
  const L = I18N[STATE.settings.lang] || I18N.uz;
  return L[key] || (I18N.uz[key] || key);
}
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ---------------- Toast ---------------- */
let toastTimer;
function toast(msg, type = '') {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'toast show ' + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = 'toast ' + type; }, 1900);
}

/* ---------------- Text-to-speech (offline Web Speech API) ---------------- */
let VOICES = [];
let TTS_UNLOCKED = false;
let _ttsWatchdog = 0;   // watchdog timer to unstick frozen TTS
let _ttsBusy = false;    // prevent overlapping speak calls
function loadVoices() {
  if (!('speechSynthesis' in window)) return;
  VOICES = speechSynthesis.getVoices() || [];
}
if ('speechSynthesis' in window) {
  loadVoices();
  speechSynthesis.onvoiceschanged = loadVoices;
}
function unlockTts() {
  if (TTS_UNLOCKED || !('speechSynthesis' in window)) return;
  try {
    const u = new SpeechSynthesisUtterance('');
    u.volume = 0;
    speechSynthesis.speak(u);
    TTS_UNLOCKED = true;
    loadVoices();
  } catch (e) {}
}
document.addEventListener('pointerdown', unlockTts, { once: false });
function pickVoice() {
  if (!VOICES.length) loadVoices();
  const want = STATE.settings.ttsVoice;
  if (want) {
    const v = VOICES.find(v => v.name === want);
    if (v) return v;
  }
  return VOICES.find(v => /en-GB/i.test(v.lang))
      || VOICES.find(v => /en-US/i.test(v.lang))
      || VOICES.find(v => /^en/i.test(v.lang))
      || null;
}
/* Force-reset TTS engine when it gets stuck (common on Android WebView). */
function ttsForceReset() {
  try {
    speechSynthesis.cancel();
    if (speechSynthesis.paused) speechSynthesis.resume();
    speechSynthesis.cancel();
  } catch(e){}
  _ttsBusy = false;
}
function speak(text) {
  if (!STATE.settings.tts || !('speechSynthesis' in window)) return;
  if (!text) return;
  unlockTts();
  // If already speaking, force cancel first to prevent queue buildup
  if (speechSynthesis.speaking || speechSynthesis.pending || _ttsBusy) {
    ttsForceReset();
    // Small delay after cancel so the engine actually resets
    setTimeout(() => speakNow(text), 80);
    return;
  }
  if (!VOICES.length) {
    loadVoices();
    if (!VOICES.length) {
      setTimeout(() => speakNow(text), 250);
      return;
    }
  }
  speakNow(text);
}
function speakNow(text) {
  try {
    speechSynthesis.cancel();
    if (speechSynthesis.paused) speechSynthesis.resume();
    _ttsBusy = true;
    const u = new SpeechSynthesisUtterance(String(text));
    const v = pickVoice();
    if (v) { u.voice = v; u.lang = v.lang; } else { u.lang = 'en-US'; }
    u.rate = Number(STATE.settings.ttsRate) || 0.9;
    u.pitch = 1;
    u.volume = 1;
    // Watchdog: if TTS doesn't finish in 8s, force reset (prevents freeze)
    clearTimeout(_ttsWatchdog);
    _ttsWatchdog = setTimeout(() => {
      if (_ttsBusy) ttsForceReset();
    }, 8000);
    u.onend = u.onerror = () => {
      clearTimeout(_ttsWatchdog);
      _ttsBusy = false;
    };
    speechSynthesis.speak(u);
    // Android WebView bug: speaking can get paused silently. Resume after 300ms.
    setTimeout(() => {
      if (speechSynthesis.paused) speechSynthesis.resume();
    }, 300);
  } catch (e) { _ttsBusy = false; }
}

/* ---------------- Vibration ---------------- */
function vibrate(pattern) {
  if (!('vibrate' in navigator)) return false;
  // A pattern of 0 (or all zeros) cancels vibration, so guard against it.
  if (typeof pattern === 'number' && pattern <= 0) return false;
  try { return navigator.vibrate(pattern); } catch (e) { return false; }
}
function buzzOk()   { vibrate(Math.min(STATE.settings.vibration || 100, 120)); }
function buzzWrong(){ const v = STATE.settings.vibration; vibrate([v, 80, v]); }

/* ---------------- Scoring & gamification ---------------- */
function xpForLevel(lvl) { return lvl * 100; } // simple curve

function addPoints(n, diff) {
  try {
    // diff bo'yicha koeffitsient: qiyinroq so'z = ko'proq ball
    const mult = (n > 0 && diff) ? (DIFF_MULTIPLIER[diff] || 1) : 1;
    const pts = Math.round(n * mult);
    STATE.points = (STATE.points || 0) + pts;
    if (pts > 0) {
      STATE.xp = (STATE.xp || 0) + pts;
      while (STATE.xp >= xpForLevel(STATE.level || 1)) {
        STATE.xp -= xpForLevel(STATE.level || 1);
        STATE.level = (STATE.level || 1) + 1;
        toast('\ud83d\ude80 ' + t('level') + ' ' + STATE.level + '!', 'gold');
        buzzOk();
      }
      // CEFR daraja o'zgarishini tekshir
      if (typeof getCefrLevel === 'function') {
        const prev = getCefrLevel(STATE.points - pts);
        const cur = getCefrLevel(STATE.points);
        if (cur.id !== prev.id) {
          toast(cur.icon + ' ' + cur.id + ' ' + cur.name + '!', 'gold');
          buzzOk();
        }
      }
    }
    if (STATE.points < 0) STATE.points = 0;
    checkAchievements();
    updateHud();
    save();
  } catch(e) { console.error('addPoints xato:', e); }
}


/* ============================================================
   CEFR PASSPORT TIZIMI
   Har CEFR darajasi uchun 5 ta mezon:
   vocab(30%), quiz(25%), speak(20%), write(15%), read(10%)
   Hammasi 100% bo'lsa — keyingi darajaga o'tish imkoni
   ============================================================ */

// Har daraja uchun talab qilinadigan minimumlar
// vocab: ko'rilgan so'zlar (seen>0) — avtomatik hisoblanadi
// quiz: quiz uchun to'plangan eng yaxshi ball (%)
// speak/write/read: bajarilgan marta soni
const LEVEL_REQ = {
  A1: { vocab: 40,  quiz: 60, speak: 3,  write: 2, read: 2  },
  A2: { vocab: 90,  quiz: 65, speak: 5,  write: 3, read: 3  },
  B1: { vocab: 140, quiz: 70, speak: 8,  write: 4, read: 4  },
  B2: { vocab: 190, quiz: 75, speak: 10, write: 5, read: 5  },
  C1: { vocab: 240, quiz: 80, speak: 12, write: 6, read: 6  },
  C2: { vocab: 290, quiz: 85, speak: 15, write: 8, read: 8  }
};
const PASSPORT_REQ = LEVEL_REQ; // eski kod uchun alias

// Og'irliklar (foiz)
const LEVEL_WEIGHTS = { vocab: 35, quiz: 25, speak: 20, write: 12, read: 8 };
const PASSPORT_WEIGHTS = LEVEL_WEIGHTS; // eski kod uchun alias

/* ---------------------------------------------------------------
   getCefrLevel OVERRIDE — passport tugalanmasa yuqori darajaga
   o'tmaymiz. data.js dagi versiyani bu versiya ustiga yozadi.
--------------------------------------------------------------- */
function getCefrLevel(pts) {
  // Birinchi: ball asosida maksimal mumkin bo'lgan darajani topamiz
  let maxByPts = CEFR_LEVELS[0];
  for (let i = CEFR_LEVELS.length - 1; i >= 0; i--) {
    if (pts >= CEFR_LEVELS[i].minPts) { maxByPts = CEFR_LEVELS[i]; break; }
  }
  // Keyin: passport tekshiruvi — quyi darajalardan ketma-ket o'tamiz
  let current = CEFR_LEVELS[0];
  for (let i = 0; i < CEFR_LEVELS.length; i++) {
    const c = CEFR_LEVELS[i];
    if (pts < c.minPts) break; // ball yetmaydi
    if (i === 0) { current = c; continue; } // A1 da boshlash uchun passport shart emas
    // Oldingi darajaning passport'i 100% bo'lganmi?
    const prevId = CEFR_LEVELS[i - 1].id;
    const prog = passportProgress(prevId);
    if (prog && prog.total >= 100) {
      current = c; // Passport tugallangan, darajaga o'tish mumkin
    } else {
      break; // Passport tugallanmagan — bu darajada qolamiz
    }
  }
  return current;
}

function ensurePassport(cefrId) {
  if (!STATE.passport) STATE.passport = {};
  if (!STATE.passport[cefrId]) {
    STATE.passport[cefrId] = { vocab: 0, quiz: 0, speak: 0, write: 0, read: 0 };
  }
  return STATE.passport[cefrId];
}

// Daraja progressini hisoblash (0-100%)
// vocab: ko'rilgan so'zlar avtomatik hisoblanadi (seen>0)
// speak/write/read: STATE.levelActivity dan olinadi
function passportProgress(cefrId) {
  const req = LEVEL_REQ[cefrId]; if (!req) return { scores:{vocab:100,quiz:100,speak:100,write:100,read:100}, total:100 };
  if (!STATE.levelActivity) STATE.levelActivity = {};
  const act = STATE.levelActivity[cefrId] || { speak:0, write:0, read:0 };
  // Vocab: shu CEFR darajasiga tegishli KO'RILGAN so'zlar
  const seenVocab = STATE.words.filter(w => w.seen > 0 && getWordCefr(w) === cefrId).length;
  // Quiz: STATE.levelQuiz dan
  if (!STATE.levelQuiz) STATE.levelQuiz = {};
  const bestQuiz = STATE.levelQuiz[cefrId] || 0;
  const scores = {
    vocab: Math.min(100, Math.round((seenVocab / req.vocab) * 100)),
    quiz:  Math.min(100, Math.round((bestQuiz   / req.quiz)  * 100)),
    speak: Math.min(100, Math.round((act.speak  / req.speak) * 100)),
    write: Math.min(100, Math.round((act.write  / req.write) * 100)),
    read:  Math.min(100, Math.round((act.read   / req.read)  * 100))
  };
  const total = Math.round(
    (scores.vocab  * LEVEL_WEIGHTS.vocab  +
     scores.quiz   * LEVEL_WEIGHTS.quiz   +
     scores.speak  * LEVEL_WEIGHTS.speak  +
     scores.write  * LEVEL_WEIGHTS.write  +
     scores.read   * LEVEL_WEIGHTS.read) / 100
  );
  return { scores, total, seenVocab, bestQuiz, act };
}

// Passport badge HTML (bosh sahifa + vocab uchun)
function passportBadgeHtml(cefrId) {
  const req = PASSPORT_REQ[cefrId]; if (!req) return '';
  const prog = passportProgress(cefrId);
  const p = ensurePassport(cefrId);
  const cefr = CEFR_LEVELS.find(c => c.id === cefrId) || {};
  const color = cefr.color || '#6d5efc';
  const items = [
    { key: 'vocab', icon: '📚', label: "So'z",     val: prog.seenVocab,       req: req.vocab,  pct: prog.scores.vocab,  weight: 35 },
    { key: 'quiz',  icon: '✅', label: 'Quiz',      val: prog.bestQuiz+'%',    req: req.quiz+'%', pct: prog.scores.quiz, weight: 25 },
    { key: 'speak', icon: '🎤', label: 'Speaking',  val: (prog.act&&prog.act.speak)||0, req: req.speak, pct: prog.scores.speak, weight: 20 },
    { key: 'write', icon: '✍️', label: 'Writing',   val: (prog.act&&prog.act.write)||0, req: req.write, pct: prog.scores.write, weight: 12 },
    { key: 'read',  icon: '📖', label: 'Reading',   val: (prog.act&&prog.act.read)||0,  req: req.read,  pct: prog.scores.read,  weight: 8  }
  ];
  return `
  <div class="passport-card" style="background:var(--card);border-radius:16px;padding:14px;margin-bottom:10px;border:2px solid ${prog.total>=100?color:'var(--line)'}">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
      <div>
        <div style="font-weight:800;font-size:14px">${cefr.icon||''} ${cefrId} → Daraja talablari</div>
        <div style="font-size:11px;color:var(--muted)">Bajarish kerak (keyingi darajaga o'tish uchun)</div>
      </div>
      <div style="font-size:22px;font-weight:800;color:${color}">${prog.total}%</div>
    </div>
    <div class="bar" style="height:10px;margin-bottom:12px;border-radius:999px">
      <i style="width:${prog.total}%;background:${color};border-radius:999px"></i>
    </div>
    ${items.map(it => `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
      <span style="font-size:14px;width:22px">${it.icon}</span>
      <div style="flex:1">
        <div style="display:flex;justify-content:space-between;margin-bottom:2px">
          <span style="font-size:12px;font-weight:600">${it.label} <span style="color:var(--muted);font-size:10px">(${it.weight}%)</span></span>
          <span style="font-size:11px;color:${it.pct>=100?color:'var(--muted)'}">${it.val}/${it.req} ${it.pct>=100?'✓':''}</span>
        </div>
        <div style="height:5px;background:var(--card2);border-radius:999px;overflow:hidden">
          <div style="height:100%;width:${it.pct}%;background:${it.pct>=100?color:'#6d5efc'};border-radius:999px;transition:.4s"></div>
        </div>
      </div>
    </div>`).join('')}
    ${prog.total >= 100
      ? `<div style="text-align:center;margin-top:8px;padding:8px;background:${color}22;border-radius:10px;color:${color};font-weight:700;font-size:13px">🎉 Keyingi darajaga o'tishga tayyor!</div>`
      : ''
    }
  </div>`;
}

// Vocab avtomatik hisoblanadi (seen>0) - bu funksiya checkni chaqiradi
function updatePassportVocab() {
  CEFR_LEVELS.forEach(c => checkPassportUnlock(c.id));
}

// Quiz natijasini saqlash
function updatePassportQuiz(cefrId, scorePct) {
  if (!STATE.levelQuiz) STATE.levelQuiz = {};
  if (scorePct > (STATE.levelQuiz[cefrId] || 0)) {
    STATE.levelQuiz[cefrId] = scorePct; save();
  }
  checkPassportUnlock(cefrId);
}

// Speaking/Writing/Reading faoliyatini saqlash
function trackPassport(cefrId, key) {
  if (!STATE.levelActivity) STATE.levelActivity = {};
  if (!STATE.levelActivity[cefrId]) STATE.levelActivity[cefrId] = { speak:0, write:0, read:0 };
  STATE.levelActivity[cefrId][key] = (STATE.levelActivity[cefrId][key] || 0) + 1;
  save();
  checkPassportUnlock(cefrId);
}

// Daraja o'tish tekshiruvi
function checkPassportUnlock(cefrId) {
  const prog = passportProgress(cefrId);
  if (prog && prog.total >= 100) {
    const idx = CEFR_LEVELS.findIndex(c => c.id === cefrId);
    if (idx >= 0 && idx < CEFR_LEVELS.length - 1) {
      const next = CEFR_LEVELS[idx + 1];
      if (!STATE.levelActivity) STATE.levelActivity = {};
      const doneKey = 'done_' + cefrId;
      if (!STATE.levelActivity[doneKey]) {
        STATE.levelActivity[doneKey] = true; save();
        setTimeout(() => {
          toast('🎉 ' + cefrId + ' tugadi! ' + next.id + ' darajasiga o\'tishingiz mumkin!', 'gold');
        }, 500);
      }
    }
  }
}

function markStudiedToday() {
  const today = todayStr();
  if (STATE.todayDay !== today) { STATE.todayDay = today; STATE.todayCount = 0; }
  STATE.todayCount++;
  // streak: consecutive calendar days
  if (STATE.lastStudyDay !== today) {
    const y = new Date(Date.now() - DAY).toISOString().slice(0, 10);
    STATE.streak = (STATE.lastStudyDay === y) ? STATE.streak + 1 : 1;
    STATE.lastStudyDay = today;
  }
}

function statsSnapshot() {
  return {
    totalLearned: STATE.words.filter(w => w.learned).length,
    streak: STATE.streak, points: STATE.points, level: STATE.level,
    spokeOnce: STATE.spokeOnce, wroteOnce: STATE.wroteOnce
  };
}

function checkAchievements() {
  const snap = statsSnapshot();
  ACHIEVEMENTS.forEach(a => {
    if (!STATE.unlocked.includes(a.id) && a.check(snap)) {
      STATE.unlocked.push(a.id);
      // Surprise! We reveal the icon but never the condition.
      toast(a.icon + ' +1', 'gold');
      buzzOk();
    }
  });
}

/* IELTS band - CEFR darajasiga asoslangan */
function estBand() {
  try {
    const cefr = getCefrLevel(STATE.points || 0);
    const parts = cefr.ielts.split('-');
    const lo = parseFloat(parts[0]), hi = parseFloat(parts[1] || parts[0]);
    const pct = cefrProgress(STATE.points || 0) / 100;
    return (lo + (hi - lo) * pct).toFixed(1);
  } catch(e) { return '0.0'; }
}
function cefrLabel() {
  try {
    const c = getCefrLevel(STATE.points || 0);
    return c.icon + ' ' + c.id + ' - ' + c.name;
  } catch(e) { return '\ud83c\udf31 A1 - Beginner'; }
}

/* ---------------- HUD ---------------- */
function updateHud() {
  $('#hudPoints').textContent = STATE.points;
  $('#hudStreak').textContent = STATE.streak;
  $('#hudLevel').textContent  = STATE.level;
}

/* ---------------- SRS core ---------------- */
/* Auto-grade by answer speed (ms): <=10s Easy, <=13s Medium, <=25s Hard. */
function gradeBySpeed(ms) {
  const s = ms / 1000;
  if (s <= 10) return 'easy';
  if (s <= 13) return 'medium';
  if (s <= 25) return 'hard';
  return 'hard';
}
function intervalDays(grade) {
  const st = STATE.settings;
  if (grade === 'easy')   return st.daysEasy;
  if (grade === 'medium') return st.daysMedium;
  if (grade === 'hard')   return st.daysHard;
  return st.daysWrong;
}
/* Apply result to a word. correct=false -> repeat soon. */
function applyResult(word, correct, ms) {
  word.seen++;
  const diff = word.diff || 2;
  if (!correct) {
    word.box = 0;
    word.due = now() + STATE.settings.daysWrong * DAY;
    // Bilmaydigan so'zlarni yig'ish uchun
    if (!word.wrongCount) word.wrongCount = 0;
    word.wrongCount++;
    word.lastWrong = now();
    addPoints(-3);
    return 'wrong';
  }
  const grade = gradeBySpeed(ms);
  word.box++;
  let days = intervalDays(grade);
  if (word.box >= 2) days = Math.max(days, [3, 7, 14, 30][Math.min(word.box - 1, 3)]);
  word.due = now() + days * DAY;
  if (word.box >= 2) { word.learned = true; updatePassportVocab(); }
  // Qiyinroq so'z = ko'proq ball (diff koeffitsienti)
  const base = grade === 'easy' ? 10 : grade === 'medium' ? 7 : 4;
  addPoints(base, diff);
  return grade;
}
function cefrMaxDiff() {
  // A1=diff1, A2=diff1+2, B1/B2=diff1+2+3, C1/C2=hammasi
  const cefr = (typeof getCefrLevel === 'function') ? getCefrLevel(STATE.points || 0) : {id:'A1'};
  if (['C1','C2'].includes(cefr.id)) return 5;
  if (['B1','B2'].includes(cefr.id)) return 3;
  if (cefr.id === 'A2') return 2;
  return 1; // A1 — faqat beginner so'zlari
}

function dueWords() {
  const ts = now();
  const maxDiff = cefrMaxDiff();
  // Faqat darajaga mos, o'zlashtirilmagan, vaqti kelgan so'zlar
  const pool = STATE.words.filter(w =>
    (w.diff || 1) <= maxDiff &&
    !w.learned &&
    (w.due || 0) <= ts
  );
  if (pool.length) return pool.sort((a,b) => (a.diff||1) - (b.diff||1));
  // Hammasi o'zlashtirilgan bo'lsa — takrorlash uchun shu darajani ko'rsat
  return STATE.words.filter(w =>
    (w.diff || 1) <= maxDiff && (w.due || 0) <= ts
  ).sort((a,b) => (a.diff||1) - (b.diff||1));
}

/* ---------------- Router ---------------- */
const ROUTES = {};
function registerRoute(name, fn) { ROUTES[name] = fn; }
let currentRoute = 'home';
function go(route) {
  currentRoute = route;
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.route === route));
  const fn = ROUTES[route] || ROUTES.home;
  $('#view').innerHTML = '';
  fn($('#view'));
  window.scrollTo(0, 0);
}

/* ---------------- HOME ---------------- */
/* ── So'z milestones badge ── */
function homeWordBadges() {
  const learned = STATE.words.filter(w => w.learned).length;
  const seen    = STATE.words.filter(w => w.seen > 0).length;
  const milestones = [
    { n:10,   icon:'🌱', label:'10 ta so\'z', color:'#27c498' },
    { n:50,   icon:'🌿', label:'50 ta so\'z', color:'#20b380' },
    { n:100,  icon:'⭐', label:'100 ta so\'z', color:'#ffd54a' },
    { n:250,  icon:'🌟', label:'250 ta so\'z', color:'#ffb020' },
    { n:500,  icon:'🔥', label:'500 ta so\'z', color:'#ff7043' },
    { n:1000, icon:'💎', label:'1000 ta so\'z', color:'#7b6cff' },
  ];
  const done = milestones.filter(m => learned >= m.n);
  const next = milestones.find(m => learned < m.n);
  if (!done.length && !next) return '';
  const badges = done.map(m =>
    `<div style="text-align:center;padding:10px 6px;background:rgba(255,255,255,.07);border-radius:12px;min-width:72px">
      <div style="font-size:28px">${m.icon}</div>
      <div style="font-size:10px;color:${m.color};font-weight:700;margin-top:3px">${m.label}</div>
      <div style="font-size:9px;color:var(--ok)">✓</div>
    </div>`
  ).join('');
  const nextHtml = next ? `
    <div style="text-align:center;padding:10px 6px;background:rgba(255,255,255,.04);border-radius:12px;min-width:72px;opacity:.5;border:1px dashed var(--line)">
      <div style="font-size:28px">${next.icon}</div>
      <div style="font-size:10px;color:var(--muted);font-weight:700;margin-top:3px">${next.label}</div>
      <div style="font-size:9px;color:var(--muted)">${learned}/${next.n}</div>
    </div>` : '';
  return `<div class="card">
    <h3>🎯 So'z nishonlari</h3>
    <div class="muted" style="font-size:12px;margin-bottom:10px">Bilingan so'zlar: <b>${learned}</b> / Ko'rilgan: <b>${seen}</b></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">${badges}${nextHtml}</div>
  </div>`;
}

registerRoute('home', (root) => {
  const due = dueWords().length;
  const goal = STATE.settings.dailyGoal;
  const today = STATE.todayDay === todayStr() ? STATE.todayCount : 0;
  const pct = Math.min(100, Math.round(today / goal * 100));
  const pts = STATE.points || 0;
  const cefr = (typeof getCefrLevel==='function') ? getCefrLevel(pts) : {id:'A1',name:'Beginner',icon:'\ud83c\udf31',color:'#27c498',ielts:'0-2.5'};
  const nxt = (typeof getNextCefr==='function') ? getNextCefr(pts) : null;
  const cpct = (typeof cefrProgress==='function') ? cefrProgress(pts) : 0;
  root.innerHTML = `
    <h1>${esc(t('welcome'))}</h1>
    <div class="card grad">
      <div style="font-size:14px;opacity:.9">${esc(t('estBand'))}</div>
      <div style="font-size:46px;font-weight:800">${estBand()}</div>
      <div style="font-size:20px;margin:6px 0">${cefr.icon} ${esc(cefr.id)} - ${esc(cefr.name)}</div>
      <div class="bar" style="background:rgba(255,255,255,.2);margin:8px 0"><i style="width:${cpct}%;background:${cefr.color}"></i></div>
      <div class="muted" style="color:#fff;opacity:.85">
        ${(function(){
        const prog = (typeof passportProgress==='function') ? passportProgress(cefr.id) : null;
        if (!nxt) return 'Maksimal daraja! \ud83c\udfc6';
        if (prog && prog.total < 100) return '\ud83d\udcc4 Daraja: ' + prog.total + '% ('+esc(nxt.id)+' uchun 100% kerak)';
        return esc(nxt.id) + ' gacha: ' + (nxt.minPts - pts) + ' ball';
      })()}
        \u2022 \ud83d\udd25 ${STATE.streak} ${esc(t('streakDays'))}
      </div>
      ${(function(){
        if(typeof passportProgress!=='function') return '';
        const prog = passportProgress(cefr.id);
        if(!prog) return '';
        const cats = [
          {icon:'\ud83d\udcda',label:"Lug'at",val:prog.scores.vocab},
          {icon:'\u2705',label:'Quiz',val:prog.scores.quiz},
          {icon:'\ud83c\udfa4',label:'Speaking',val:prog.scores.speak},
          {icon:'\u270d\ufe0f',label:'Writing',val:prog.scores.write},
          {icon:'\ud83d\udcd6',label:'Reading',val:prog.scores.read}
        ];
        return '<div style="margin-top:10px;border-top:1px solid rgba(255,255,255,.2);padding-top:10px">'
          + '<div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:6px">'
          + '<span>\ud83d\udcc4 Passport</span>'
          + '<span style="font-weight:700">' + prog.total + '%</span></div>'
          + '<div style="height:5px;background:rgba(255,255,255,.2);border-radius:999px;margin-bottom:8px">'
          + '<div style="height:100%;width:' + prog.total + '%;background:' + (cefr.color||'#6d5efc') + ';border-radius:999px;transition:.4s"></div></div>'
          + '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:3px;text-align:center">'
          + cats.map(function(c){return '<div style="font-size:10px">'
            + '<div>' + c.icon + '</div>'
            + '<div style="height:3px;background:rgba(255,255,255,.25);border-radius:999px;margin:2px 0">'
            + '<div style="height:100%;width:' + c.val + '%;background:' + (c.val>=100?'#4ade80':'rgba(255,255,255,.7)') + ';border-radius:999px;transition:.3s"></div></div>'
            + '<div style="opacity:.8">' + c.val + '%</div>'
            + '</div>';}).join('')
          + '</div>'
          + (prog.total>=100 ? '<div style="margin-top:8px;text-align:center;font-size:12px;font-weight:700;color:#4ade80">\ud83c\udf89 Daraja o\u2019tishga tayyor!</div>' : '')
          + '</div>';
      })()}
    </div>
    <div class="card">
      <h3>${esc(t('dailyGoal'))}</h3>
      <div class="bar"><i style="width:${pct}%"></i></div>
      <div class="muted" style="margin-top:6px">${esc(t('wordsToday'))}: ${today} / ${goal}</div>
    </div>
    <div class="card">
      <h3>${esc(t('dueNow'))}</h3>
      ${due > 0
        ? `<p class="muted">${due} ${esc(t('dueCount'))}</p>
           <button class="btn" id="goLearn">${esc(t('startReview'))}</button>`
        : `<p class="empty"><span>\ud83c\udf89</span>${esc(t('noDue'))}</p>`}
    </div>
    <div class="card">
      <h3>${esc(t('quickActions'))}</h3>
      <div class="row">
        <button class="btn sec" id="qVocab">\ud83d\udcda ${esc(t('navVocab'))}</button>
        <button class="btn sec" id="qFlash">\ud83c\udccf Flashcards</button>
      </div>
      <div class="row" style="margin-top:10px">
        <button class="btn sec" id="qIelts">\ud83c\udf93 ${esc(t('navIelts'))}</button>
        <button class="btn sec" id="qQuiz">\u23f1\ufe0f Quiz</button>
      </div>
      <div class="row" style="margin-top:10px">
        <button class="btn" id="qWordTest" style="background:var(--ok)">\ud83d\udcdd ${esc(t('wordTest'))}</button>
      </div>
      <div class="row" style="margin-top:10px">
        <button class="btn sec" id="qWeak">\ud83d\udca1 ${esc(t('weakWords'))}</button>
        <button class="btn sec" id="qShop">\ud83c\udfaa ${esc(t('shop'))}</button>
      </div>
    </div>
    <div style="margin-top:4px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <h2 style="margin:0;font-size:16px">📋 Daraja Talablari</h2>
        <button id="passportToggle" style="background:none;border:none;color:var(--muted);font-size:12px;cursor:pointer">Ko'rish ▾</button>
      </div>
      <div id="passportSection" style="display:none">
        ${passportBadgeHtml(cefr.id)}
      </div>
    </div>
    ${homeWordBadges()}<div style='height:8px'></div>`;
  const gl = $('#goLearn'); if (gl) gl.onclick = () => go('learn');
  $('#qVocab').onclick = () => go('vocab');
  $('#qFlash').onclick = () => go('flash');
  $('#qIelts').onclick = () => go('ielts');
  $('#qQuiz').onclick = () => go('quiz');
  $('#qWeak').onclick = () => go('weak');
  $('#qShop').onclick = () => go('shop');
  $('#qWordTest').onclick = () => go('wordtest');
  // Passport toggle
  const pToggle = document.getElementById('passportToggle');
  const pSection = document.getElementById('passportSection');
  if (pToggle && pSection) {
    pToggle.onclick = () => {
      const open = pSection.style.display !== 'none';
      pSection.style.display = open ? 'none' : 'block';
      pToggle.textContent = open ? "Ko'rish ▾" : "Yopish ▲";
    };
  }
});

/* ---------------- VOCABULARY ---------------- */
let vocabFilter = 'all';
let vocabSearch = '';
let vocabCefrFilter = null; // null = hammasi, 'A1','A2',... = faqat o'sha daraja
let expandedCefr = null;    // accordion: qaysi daraja ochiq

// CEFR darajasi -> diff raqami mapping
const CEFR_DIFF_MAP = {A1:1, A2:1, B1:2, B2:2, C1:3, C2:3};
// Har CEFR darajasiga xos diff (aniqroq filtrlash uchun level index)
const CEFR_LEVEL_IDX = {A1:0, A2:1, B1:2, B2:3, C1:4, C2:5};

registerRoute('vocab', (root) => {
  const total = STATE.words.length;
  const mastered = STATE.words.filter(w => w.learned).length;
  const pct = total ? Math.round(mastered / total * 100) : 0;
  const cefr = getCefrLevel(STATE.points || 0);
  const cefrPct = (typeof cefrProgress === 'function') ? cefrProgress(STATE.points || 0) : 0;
  const pts = STATE.points || 0;

  // Har CEFR daraja uchun so'zlar soni
  function cefrWordCount(cefrId) {
    const diff = CEFR_DIFF_MAP[cefrId] || 1;
    const idx  = CEFR_LEVEL_IDX[cefrId] || 0;
    // A1 va A2 ikkalasi ham diff:1, lekin biz A2 uchun ham diff:1 so'zlarni ko'rsatamiz
    // Faqat ajratish: A1=diff1 (birinchi 100), A2=diff1 (keyingi), B1=diff2 first half, B2=diff2 second half, C1=diff3 first, C2=diff3 second
    return STATE.words.filter(w => getWordCefr(w) === cefrId).length;
  }

  root.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
      <h1 style="margin:0">${esc(t('vocabTitle'))}</h1>
      <button id="vAiImportTop" style="background:linear-gradient(135deg,#6d5efc,#27c498);color:#fff;border:none;border-radius:999px;padding:9px 14px;font-size:12px;font-weight:700;box-shadow:0 4px 12px rgba(109,94,252,.4);white-space:nowrap;cursor:pointer">🤖 AI So'z</button>
    </div>
    <div class="card" style="padding:12px;margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <span style="font-size:15px;font-weight:800">${cefr.icon} ${esc(cefr.id)} — ${esc(cefr.name)}</span>
        <span class="muted" style="font-size:12px">${pts} ball</span>
      </div>
      <div class="bar" style="height:8px;margin-bottom:6px"><i style="width:${cefrPct}%;background:${cefr.color}"></i></div>
      <div style="display:flex;justify-content:space-between">
        ${CEFR_LEVELS.map(c => `<span style="font-size:10px;font-weight:700;color:${pts>=c.minPts?c.color:'var(--muted)'}">${esc(c.id)}</span>`).join('')}
      </div>
    </div>
    <div class="card" style="padding:12px;margin-bottom:10px">
      <div class="muted" style="margin-bottom:6px">${esc(t('mastered'))}: ${mastered} / ${total} (${pct}%)</div>
      <div class="bar"><i style="width:${pct}%"></i></div>
    </div>
    <input id="vSearch" placeholder="${esc(t('searchWord'))}" value="${esc(vocabSearch)}" />
    <div class="tag-row">
      <div class="tag ${vocabFilter==='all'&&!vocabCefrFilter?'active':''}" data-f="all">${esc(t('all'))}</div>
      <div class="tag ${vocabFilter==='new'?'active':''}" data-f="new">${esc(t('newp'))}</div>
      <div class="tag ${vocabFilter==='learning'?'active':''}" data-f="learning">${esc(t('learning'))}</div>
      <div class="tag ${vocabFilter==='mastered'?'active':''}" data-f="mastered">${esc(t('mastered'))}</div>
    </div>

    <!-- CEFR accordion darajalar -->
    <div id="cefrAccordion" style="margin-bottom:8px">
      ${CEFR_LEVELS.map(c => {
        const unlocked = (typeof getCefrLevel==='function') ? (getCefrLevel(pts).id===c.id || CEFR_LEVELS.findIndex(x=>x.id===getCefrLevel(pts).id) >= CEFR_LEVELS.findIndex(x=>x.id===c.id)) : pts >= c.minPts;
        const isOpen = expandedCefr === c.id;
        const isActive = vocabCefrFilter === c.id;
        const wCount = cefrWordCount(c.id);
        return `
        <div class="cefr-section" style="margin-bottom:6px">
          <div class="cefr-header card" data-cefr="${c.id}" style="padding:12px 14px;cursor:pointer;display:flex;align-items:center;justify-content:space-between;border:2px solid ${isActive?c.color:'transparent'};transition:border .2s">
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:18px">${c.icon}</span>
              <div>
                <div style="font-weight:800;font-size:14px;color:${unlocked?c.color:'var(--muted)'}">${esc(c.id)} — ${esc(c.name)}</div>
                <div style="font-size:11px;color:var(--muted)">${wCount} so\'z${unlocked?'':' · \ud83d\udd12 Oldingi passport kerak'}</div>
              </div>
            </div>
            <span style="font-size:18px;transition:transform .3s;display:inline-block;transform:rotate(${isOpen?'90':'0'}deg);color:var(--muted)">›</span>
          </div>
          <div class="cefr-body" id="cefrBody_${c.id}" style="display:${isOpen?'block':'none'};padding:0 4px">
            ${isOpen ? renderCefrWordList(c.id) : ''}
          </div>
        </div>`;
      }).join('')}
    </div>

    <div id="vList" style="${vocabCefrFilter?'display:none':''}"></div>
    <div id="vocabFabs" style="position:fixed;right:16px;bottom:calc(72px + env(safe-area-inset-bottom, 0px));z-index:50;display:flex;flex-direction:column;gap:8px;align-items:flex-end"></div>`;

  $('#vSearch').oninput = (e) => { vocabSearch = e.target.value; renderVList(); refreshOpenCefrBody(); };

  $$('.tag', root).forEach(tg => tg.onclick = () => {
    vocabFilter = tg.dataset.f;
    vocabCefrFilter = null;
    expandedCefr = null;
    go('vocab');
  });

  // CEFR accordion click
  $$('.cefr-header', root).forEach(hdr => {
    hdr.onclick = () => {
      const cId = hdr.dataset.cefr;
      const lvl = CEFR_LEVELS.find(x => x.id === cId);
      const pts2 = STATE.points || 0;
      if (pts2 < (lvl ? lvl.minPts : 0) && lvl && lvl.minPts > 0) {
        toast('🔒 Bu daraja uchun ' + lvl.minPts + ' ball kerak!'); return;
      }
      if (expandedCefr === cId) {
        expandedCefr = null;
        vocabCefrFilter = null;
      } else {
        expandedCefr = cId;
        vocabCefrFilter = cId;
        vocabFilter = 'all';
      }
      go('vocab');
    };
  });

  if (!vocabCefrFilter) renderVList();

  // FABs
  const fabsEl = document.getElementById('vocabFabs');
  if (fabsEl) {
    fabsEl.innerHTML = `<button class="fab" id="vAdd" title="${t('addWord')}">+</button>`;
    document.getElementById('vAdd').onclick = () => openWordForm();
  }
  const aiBtn = document.getElementById('vAiImportTop');
  if (aiBtn) aiBtn.onclick = () => openAiImport();
});

// So'zning CEFR darajasini aniqlash (diff va so'z indeksiga qarab)
function getWordCefr(w) {
  const diff = w.diff || 2;
  if (diff === 1) {
    // diff:1 so'zlar A1 va A2 ga bo'linadi: id 'd1'-'d50' -> A1, 'd51'-... -> A2
    const num = parseInt((w.id || '').replace(/\D/g, '')) || 0;
    if (w.id && w.id.startsWith('d')) return num <= 50 ? 'A1' : 'A2';
    return 'A1';
  }
  if (diff === 2) {
    // diff:2 -> B1 va B2: w1-w40 -> B1, w41-... -> B2
    const num = parseInt((w.id || '').replace(/\D/g, '')) || 0;
    if (w.id && w.id.startsWith('w')) return num <= 40 ? 'B1' : 'B2';
    return 'B1';
  }
  if (diff === 3) {
    // diff:3 -> C1 va C2
    const num = parseInt((w.id || '').replace(/\D/g, '')) || 0;
    return num <= 5 ? 'C1' : 'C2';
  }
  return 'B1';
}

// Ochiq CEFR body ni yangilash (qidiruv bor bo'lganda)
function refreshOpenCefrBody() {
  if (!expandedCefr) return;
  const body = document.getElementById('cefrBody_' + expandedCefr);
  if (body) body.innerHTML = renderCefrWordList(expandedCefr);
}

// CEFR darajasiga tegishli so'zlar HTMLini render qilish
function renderCefrWordList(cefrId) {
  const q = vocabSearch.trim().toLowerCase();
  let words = STATE.words.filter(w => getWordCefr(w) === cefrId);
  if (q) words = words.filter(w => w.word.toLowerCase().includes(q) || (w.tr||'').toLowerCase().includes(q));
  if (!words.length) return `<p class="empty" style="font-size:13px;padding:10px 0"><span>💬</span> So'z topilmadi</p>`;
  const html = words.map(w => `
    <div class="card" style="padding:10px;margin-bottom:6px">
      <div class="list-item" style="border:none;padding:0">
        <div style="flex:1;cursor:pointer" data-open="${w.id}">
          <div class="w">${esc(w.word)}
            ${w.learned ? '<span class="pill easy">✓</span>' : (w.seen>0?'<span class="pill medium">…</span>':'<span class="pill new">Yangi</span>')}
          </div>
          <div class="t">${esc(w.tr)}</div>
        </div>
        <button class="speak" data-say="${esc(w.word)}">🔊</button>
      </div>
      <div class="detail" id="d_${w.id}" style="display:none;margin-top:10px">
        <div class="note">"${esc(w.ex)}"</div>
        ${w.used ? `<div class="muted">${esc(t('usedIn'))}: ${esc(w.used)}</div>` : ''}
        <div class="row tight" style="margin-top:10px">
          <button class="btn sec sm" data-edit="${w.id}">✎ ${esc(t('edit'))}</button>
          <button class="btn err sm" data-del="${w.id}">🗑 ${esc(t('delete'))}</button>
        </div>
      </div>
    </div>`).join('');

  // Attach events after slight delay
  setTimeout(() => {
    const body = document.getElementById('cefrBody_' + cefrId);
    if (!body) return;
    body.querySelectorAll('[data-say]').forEach(b => b.onclick = (e) => { e.stopPropagation(); speak(b.dataset.say); });
    body.querySelectorAll('[data-open]').forEach(el => el.onclick = () => {
      const d = document.getElementById('d_' + el.dataset.open);
      if (d) { const open = d.style.display === 'none'; d.style.display = open ? 'block' : 'none'; }
    });
    body.querySelectorAll('[data-del]').forEach(b => b.onclick = () => {
      STATE.words = STATE.words.filter(x => x.id !== b.dataset.del); save();
      toast(t('wordDeleted')); refreshOpenCefrBody();
    });
    body.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => {
      const w = STATE.words.find(x => x.id === b.dataset.edit); openWordForm(w);
    });
  }, 0);

  return html;
}

function filterWords() {
  const q = vocabSearch.trim().toLowerCase();
  return STATE.words.filter(w => {
    if (vocabFilter === 'new' && (w.seen > 0)) return false;
    if (vocabFilter === 'learning' && !(w.seen > 0 && !w.learned)) return false;
    if (vocabFilter === 'mastered' && !w.learned) return false;
    if (q && !(w.word.toLowerCase().includes(q) || (w.tr || '').toLowerCase().includes(q))) return false;
    return true;
  });
}

function renderVList() {
  const list = $('#vList'); if (!list) return;
  const words = filterWords();
  if (!words.length) { list.innerHTML = `<p class="empty"><span>\ud83d\udcad</span>${esc(t('noWords'))}</p>`; return; }
  list.innerHTML = words.map(w => `
    <div class="card" style="padding:12px">
      <div class="list-item" style="border:none;padding:0">
        <div style="flex:1;cursor:pointer" data-open="${w.id}">
          <div class="w">${esc(w.word)}
            ${w.learned ? '<span class="pill easy">\u2713</span>' : (w.seen>0?'<span class="pill medium">\u2026</span>':'<span class="pill new">'+esc(t('newp'))+'</span>')}
          </div>
          <div class="t">${esc(w.tr)}</div>
        </div>
        <button class="speak" data-say="${esc(w.word)}">\ud83d\udd0a</button>
      </div>
      <div class="detail" id="d_${w.id}" style="display:none;margin-top:10px">
        <div class="note">\u201c${esc(w.ex)}\u201d</div>
        ${w.used ? `<div class="muted">${esc(t('usedIn'))}: ${esc(w.used)}</div>` : ''}
        <div class="row tight" style="margin-top:10px">
          <button class="btn sec sm" data-edit="${w.id}">\u270e ${esc(t('edit'))}</button>
          <button class="btn err sm" data-del="${w.id}">\ud83d\uddd1 ${esc(t('delete'))}</button>
        </div>
      </div>
    </div>`).join('');

  $$('[data-say]', list).forEach(b => b.onclick = (e) => { e.stopPropagation(); speak(b.dataset.say); });
  $$('[data-open]', list).forEach(el => el.onclick = () => {
    const d = $('#d_' + el.dataset.open);
    const open = d.style.display === 'none';
    d.style.display = open ? 'block' : 'none';
    if (open && STATE.settings.autoSpeak) {
      const w = STATE.words.find(x => x.id === el.dataset.open);
      if (w) speak(w.word);
    }
  });
  $$('[data-del]', list).forEach(b => b.onclick = () => {
    STATE.words = STATE.words.filter(x => x.id !== b.dataset.del); save();
    toast(t('wordDeleted')); renderVList();
  });
  $$('[data-edit]', list).forEach(b => b.onclick = () => {
    const w = STATE.words.find(x => x.id === b.dataset.edit); openWordForm(w);
  });
}

/* Add / edit word form (modal-ish view) */
function openWordForm(word) {
  const editing = !!word;
  const v = $('#view');
  v.innerHTML = `
    <h1>${editing ? esc(t('edit')) : esc(t('addWord'))}</h1>
    <div class="card">
      <label>${esc(t('word'))}</label>
      <input id="fWord" value="${editing?esc(word.word):''}" />
      <label>${esc(t('translation'))}</label>
      <input id="fTr" value="${editing?esc(word.tr):''}" />
      <label>${esc(t('example'))}</label>
      <textarea id="fEx">${editing?esc(word.ex):''}</textarea>
      <label>${esc(t('usedIn'))}</label>
      <input id="fUsed" value="${editing?esc(word.used||''):''}" />
      <div class="row">
        <button class="btn sec" id="fCancel">${esc(t('cancel'))}</button>
        <button class="btn" id="fSave">${esc(t('save'))}</button>
      </div>
    </div>`;
  $('#fCancel').onclick = () => go('vocab');
  $('#fSave').onclick = () => {
    const word_ = $('#fWord').value.trim();
    const tr_   = $('#fTr').value.trim();
    if (!word_ || !tr_) { toast(t('word') + ' + ' + t('translation'), 'err'); return; }
    if (editing) {
      word.word = word_; word.tr = tr_; word.ex = $('#fEx').value.trim(); word.used = $('#fUsed').value.trim();
    } else {
      STATE.words.push({
        id: 'u' + now(), word: word_, tr: tr_,
        ex: $('#fEx').value.trim(), used: $('#fUsed').value.trim(),
        box: 0, due: 0, seen: 0, learned: false
      });
    }
    save(); toast(t('wordAdded'), 'ok'); go('vocab');
  };
}

/* ---------------- AI BULK WORD IMPORT ---------------- */
function openAiImport() {
  const v = $('#view');
  const cefr = getCefrLevel(STATE.points || 0);
  const cefrToDiff = {A1:1, A2:1, B1:2, B2:2, C1:3, C2:3};

  // Foydalanuvchi tanlagan daraja (default: o'zining hozirgi darajasi)
  let selCefr = cefr.id;
  let myDiff = cefrToDiff[selCefr] || 1;

  const levelPrompts = {
    A1: `A1 (Beginner) darajasidagi ingliz so'zlari. Faqat eng oddiy, kundalik hayotda tez-tez ishlatiladigan so'zlar. Murakkab so'zlar bo'lmasin.`,
    A2: `A2 (Elementary) darajasidagi ingliz so'zlari. Oddiy kundalik so'zlar, Elementary daraja.`,
    B1: `B1 (Intermediate) darajasidagi ingliz so'zlari. O'rta daraja, IELTS 4-5 da uchraydigan so'zlar.`,
    B2: `B2 (Upper-Intermediate) darajasidagi ingliz so'zlari. IELTS 5.5-6.5 da uchraydigan so'zlar.`,
    C1: `C1 (Advanced) darajasidagi ingliz so'zlari. Ilg'or, akademik, murakkab so'zlar. IELTS 7-8 darajasi.`,
    C2: `C2 (Proficiency) darajasidagi ingliz so'zlari. Native speaker darajasi, IELTS 8.5-9.`
  };

  const topicPrompts = {
    kundalik: 'kundalik hayot (uy, oila, do\'stlar, xarid, ovqat)',
    ish: 'ish va kasb (ofis, yig\'ilish, loyiha, martaba)',
    sayohat: 'sayohat (aeroport, mehmonxona, shahar, transport)',
    ovqat: 'ovqat va ichimlik (restoran, retsept, ingredientlar)',
    texnologiya: 'texnologiya (smartfon, internet, dastur, ijtimoiy tarmoq)',
    sport: 'sport va jismoniy faoliyat (mashg\'ulot, musobaqa)',
    tabiat: 'tabiat va atrof-muhit (hayvonlar, o\'simliklar, iqlim)',
    aralash: 'turli mavzular (grammatika, his-tuyg\'ular, vaqt, joylar)'
  };

  let selTopic = 'kundalik';
  let selCount = 100;

  function buildPrompt() {
    return `Menga ${selCount} ta ingliz so'zi bering.

Daraja: ${levelPrompts[selCefr]}
Mavzu: ${topicPrompts[selTopic]}

FAQAT quyidagi JSON formatida javob bering, boshqa hech narsa yozmang:
[
  {"word": "inglizcha so'z", "tr": "o'zbekcha tarjima", "ex": "Example sentence in English."},
  ...
]

Qoidalar:
- "word" = inglizcha so'z yoki ibora
- "tr" = o'zbekcha tarjima (qisqa, aniq)
- "ex" = qisqa inglizcha misol gap
- Takrorlanma, darajaga to'g'ri keladigan so'zlar`;
  }

  function renderStep1() {
    const pts = STATE.points || 0;
    v.innerHTML = `
      <h1>🤖 AI orqali so'z qo'shish</h1>
      <div class="card grad" style="margin-bottom:14px">
        <div style="font-size:12px;opacity:.8">Sizning darajangiz</div>
        <div style="font-size:20px;font-weight:800">${cefr.icon} ${cefr.id} — ${cefr.name}</div>
      </div>
      <div class="card" style="margin-bottom:10px">
        <h3>🎓 Qaysi darajaga qo'shish?</h3>
        <div class="tag-row" id="cefrRow" style="flex-wrap:wrap;gap:8px">
          ${CEFR_LEVELS.map(c => {
            const unlocked = (typeof getCefrLevel==='function') ? (getCefrLevel(pts).id===c.id || CEFR_LEVELS.findIndex(x=>x.id===getCefrLevel(pts).id) >= CEFR_LEVELS.findIndex(x=>x.id===c.id)) : pts >= c.minPts;
            return `<div class="tag ${selCefr===c.id?'active':''} ${!unlocked?'locked-tag':''}" data-cefr="${c.id}" style="opacity:${unlocked?1:.45};${!unlocked?'cursor:not-allowed;':''}">${c.icon} ${c.id}</div>`;
          }).join('')}
        </div>
        <div id="cefrHint" style="font-size:11px;color:var(--muted);margin-top:8px">
          ${CEFR_LEVELS.find(c=>c.id===selCefr)?.name || ''} darajasiga qo'shiladi
        </div>
      </div>
      <div class="card">
        <h3>📋 Mavzu</h3>
        <div class="tag-row" id="topicRow">
          <div class="tag active" data-topic="kundalik">🏠 Kundalik</div>
          <div class="tag" data-topic="ish">💼 Ish</div>
          <div class="tag" data-topic="sayohat">✈️ Sayohat</div>
          <div class="tag" data-topic="ovqat">🍕 Ovqat</div>
          <div class="tag" data-topic="texnologiya">💻 Tech</div>
          <div class="tag" data-topic="sport">⚽ Sport</div>
          <div class="tag" data-topic="tabiat">🌿 Tabiat</div>
          <div class="tag" data-topic="aralash">🎲 Aralash</div>
        </div>
      </div>
      <div class="card">
        <h3>🔢 Nechta so'z?</h3>
        <div class="tag-row" id="countRow">
          <div class="tag" data-count="50">50</div>
          <div class="tag active" data-count="100">100</div>
          <div class="tag" data-count="200">200</div>
          <div class="tag" data-count="300">300</div>
        </div>
      </div>
      <button class="btn" id="aiNextBtn">📋 Prompt olish →</button>
      <button class="btn sec" id="aiBack">← Ortga</button>`;

    // CEFR level selector (index-based: matches CEFR_LEVELS order)
    const cefrEls = $$('#cefrRow .tag', v);
    cefrEls.forEach((el, i) => {
      el.onclick = () => {
        const c = CEFR_LEVELS[i];
        if (pts < (c?.minPts || 0)) { toast('🔒 ' + c.minPts + ' ball kerak!'); return; }
        selCefr = c.id;
        myDiff = cefrToDiff[selCefr] || 1;
        cefrEls.forEach(x => x.classList.remove('active'));
        el.classList.add('active');
        const hint = document.getElementById('cefrHint');
        if (hint) hint.textContent = (CEFR_LEVELS.find(c2=>c2.id===selCefr)?.name||'') + ' darajasiga qo\'shiladi';
      };
    });
    // Topic selector (index-based: matches topicKeys order)
    const topicKeys = ['kundalik','ish','sayohat','ovqat','texnologiya','sport','tabiat','aralash'];
    $$('#topicRow .tag', v).forEach((el, i) => {
      el.onclick = () => { $$('#topicRow .tag', v).forEach(x => x.classList.remove('active')); el.classList.add('active'); selTopic = topicKeys[i] || 'kundalik'; };
    });
    // Count selector (parse number from text)
    $$('#countRow .tag', v).forEach(el => {
      el.onclick = () => { $$('#countRow .tag', v).forEach(x => x.classList.remove('active')); el.classList.add('active'); selCount = parseInt(el.textContent) || 100; };
    });
    $('#aiNextBtn').onclick = () => renderStep2();
    $('#aiBack').onclick = () => go('vocab');
  }

  function renderStep2() {
    const prompt = buildPrompt();
    v.innerHTML = `
      <h1>📋 Promptni nusxalang</h1>
      <div class="card" style="margin-bottom:10px;background:rgba(109,94,252,.15);border:1px solid #6d5efc">
        <div style="font-size:12px;font-weight:700;color:#a0a0ff;margin-bottom:8px">1️⃣ Quyidagi matnni nusxalang:</div>
        <div id="promptBox" style="font-size:12px;line-height:1.6;white-space:pre-wrap;word-break:break-word;color:#e0e0ff;background:rgba(0,0,0,.3);padding:10px;border-radius:8px">${prompt}</div>
        <button class="btn" id="copyPromptBtn" style="margin-top:10px;font-size:13px">📋 Nusxalash</button>
      </div>
      <div class="card" style="margin-bottom:10px;background:rgba(39,196,152,.1);border:1px solid #27c498">
        <div style="font-size:12px;font-weight:700;color:#27c498;margin-bottom:6px">2️⃣ ChatGPT yoki Claude ga yuboring va javobni nusxalang</div>
        <div style="font-size:11px;opacity:.7">chatgpt.com yoki claude.ai ga o'ting → promptni paste qiling → javobni nusxalang</div>
      </div>
      <div class="card">
        <div style="font-size:12px;font-weight:700;margin-bottom:8px">3️⃣ AI javobini shu yerga paste qiling:</div>
        <textarea id="aiPasteArea" placeholder='[ {"word": "...", "tr": "...", "ex": "..."}, ... ]' style="width:100%;min-height:120px;background:rgba(255,255,255,.07);border:1px solid var(--line);border-radius:10px;padding:10px;color:var(--txt);font-size:12px;resize:vertical;box-sizing:border-box"></textarea>
        <button class="btn" id="aiParseBtn" style="margin-top:10px">✅ So'zlarni qo'shish</button>
      </div>
      <button class="btn sec" id="aiBackStep1">← Ortga</button>`;

    $('#copyPromptBtn').onclick = () => {
      navigator.clipboard.writeText(prompt).then(() => {
        $('#copyPromptBtn').textContent = '✅ Nusxalandi!';
        setTimeout(() => { $('#copyPromptBtn').textContent = '📋 Nusxalash'; }, 2000);
      }).catch(() => {
        // fallback
        const ta = document.createElement('textarea');
        ta.value = prompt; ta.style.position='fixed'; ta.style.opacity='0';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy');
        document.body.removeChild(ta);
        $('#copyPromptBtn').textContent = '✅ Nusxalandi!';
        setTimeout(() => { $('#copyPromptBtn').textContent = '📋 Nusxalash'; }, 2000);
      });
    };

    $('#aiParseBtn').onclick = () => {
      const raw = $('#aiPasteArea').value.trim();
      if (!raw) { toast('❌ Avval javobni paste qiling!', 'err'); return; }
      try {
        const clean = raw.replace(/```json|```/g, '').trim();
        const words = JSON.parse(clean);
        if (!Array.isArray(words) || !words.length) throw new Error('Bo\'sh');
        renderStep3(words);
      } catch(e) {
        toast('❌ Format xato! JSON kerak', 'err');
      }
    };
    $('#aiBackStep1').onclick = () => renderStep1();
  }

  function renderStep3(words) {
    const existingWords = new Set(STATE.words.map(w => (w.word||'').toLowerCase()));
    const newWords = words.filter(w => w && w.word && !existingWords.has(w.word.toLowerCase().trim()));
    const dupes = words.length - newWords.length;

    v.innerHTML = `
      <h1>✅ So'zlar tayyor!</h1>
      <div class="card" style="background:rgba(39,196,152,.15);border:1px solid #27c498;margin-bottom:14px">
        <div style="font-size:22px;font-weight:800;color:#27c498">${newWords.length} ta yangi so'z</div>
        ${dupes > 0 ? `<div style="font-size:12px;opacity:.7;margin-top:4px">(${dupes} ta allaqachon bor — o'tkazib yuborildi)</div>` : ''}
        <div style="font-size:12px;margin-top:6px;opacity:.8">Daraja: ${(CEFR_LEVELS.find(c=>c.id===selCefr)||cefr).icon} ${selCefr}</div>
      </div>
      <div class="card" style="max-height:280px;overflow-y:auto;margin-bottom:14px">
        ${newWords.slice(0, 15).map(w => `
          <div style="display:flex;align-items:baseline;padding:6px 0;border-bottom:1px solid var(--line)">
            <span style="font-weight:700;min-width:120px">${esc(w.word)}</span>
            <span class="muted" style="font-size:12px">— ${esc(w.tr)}</span>
          </div>`).join('')}
        ${newWords.length > 15 ? `<div class="muted" style="text-align:center;padding:8px;font-size:12px">... va yana ${newWords.length - 15} ta</div>` : ''}
      </div>
      <button class="btn" id="aiSaveAll">💾 ${newWords.length} ta so'zni saqlash</button>
      <button class="btn sec" id="aiMoreWords" style="margin-top:8px">🔄 Yana so'z olish</button>
      <button class="btn sec" id="aiCancel" style="margin-top:8px">← Bekor qilish</button>`;

    $('#aiSaveAll').onclick = () => {
      const ts = Date.now();
      newWords.forEach((w, i) => {
        if (!w.word || !w.tr) return;
        STATE.words.push({
          id: 'ai' + ts + i,
          word: w.word.trim(),
          tr: w.tr.trim(),
          ex: (w.ex || '').trim(),
          used: (w.used || '').trim(),
          diff: myDiff,
          box: 0, due: 0, seen: 0, learned: false
        });
      });
      save();
      toast('✅ ' + newWords.length + ' ta so\'z qo\'shildi!', 'ok');
      go('vocab');
    };
    $('#aiMoreWords').onclick = () => renderStep2();
    $('#aiCancel').onclick = () => go('vocab');
  }

  renderStep1();
}



/* ---------------- SHOP (sirli sovg'alar do'koni) ---------------- */
registerRoute('shop', (root) => {
  if (!Array.isArray(STATE.purchased)) STATE.purchased = [];
  const cefr = getCefrLevel(STATE.points);
  root.innerHTML = `
    <h1>\ud83c\udfaa ${esc(t('shop'))} <span class="muted" style="font-size:14px">\ud83d\udc8e ${STATE.points}</span></h1>
    <p class="muted">${esc(t('shopDesc'))}</p>
    <div id="shopList"></div>
    <button class="btn sec" id="bHome" style="margin-top:14px">\ud83c\udfe0</button>`;
  const list = $('#shopList');
  SHOP_ITEMS.forEach(item => {
    const bought = STATE.purchased.includes(item.id);
    const cefrOk = STATE.points >= (CEFR_LEVELS.find(c=>c.id===item.cefrMin)||{minPts:0}).minPts;
    const canBuy = !bought && cefrOk && STATE.points >= item.price;
    const locked = !cefrOk;
    list.innerHTML += `
      <div class="card ${locked?'locked-card':''}" style="padding:12px;opacity:${locked?0.4:1}">
        <div class="list-item" style="border:none;padding:0">
          <div style="flex:1">
            <div class="w">${item.icon} ${esc(item.name)}
              ${bought?'<span class="pill easy">\u2713</span>':''}
              ${locked?'<span class="pill hard">\ud83d\udd12 '+esc(item.cefrMin)+'</span>':''}
            </div>
            <div class="t">${esc(item.price)} \ud83d\udc8e ${locked?'('+esc(item.cefrMin)+' daraja kerak)':''}</div>
          </div>
          ${bought?'':'<button class="btn sm ' + (canBuy?'':'sec') + '" data-buy="'+item.id+'" '+(canBuy?'':'disabled')+'>'}
            +(locked?'\ud83d\udd12':'\ud83c\udfb0 '+esc(t('buy')))+
          '</button>'}
        </div>
        ${bought?'<div class="note" style="margin-top:8px">'+esc(item.reward)+'</div>':''}
      </div>`;
  });
  $$('[data-buy]', root).forEach(b => b.onclick = () => spinAndBuy(b.dataset.buy, root));
  $('#bHome').onclick = () => go('home');
});

/* ── Sovg'a turi bo'yicha emoji to'plamlari ── */
const SPIN_EMOJIS = {
  badge:         ['🏅','🎖️','🏆','👑','💠','🌟','⭐','✨'],
  bonus_xp:      ['⚡','🔋','💥','🔥','✨','💫','⚡','🌟'],
  mystery:       ['🎴','📦','🗝️','🎁','❓','🔮','🎲','🎭'],
  streak_shield: ['🛡️','⚔️','🛡️','💪','🔰','🛡️','✅','🛡️'],
  avatar:        ['🖼️','🌈','🎨','✨','🖌️','🌟','🎭','🖼️'],
  idiom:         ['💬','🗣️','📢','💡','🎤','💬','📝','💬'],
  default:       ['🎁','💎','⭐','🔥','🎉','🌟','🏆','✨']
};

function spinAndBuy(itemId, root) {
  const item = SHOP_ITEMS.find(i=>i.id===itemId);
  if (!item || STATE.points < item.price) { toast(t('notEnough'),'err'); return; }
  if (!Array.isArray(STATE.purchased)) STATE.purchased = [];
  if (STATE.purchased.includes(itemId)) return;

  const v = $('#view');
  const emojis = SPIN_EMOJIS[item.type] || SPIN_EMOJIS.default;
  let spinIdx = 0, spins = 0;
  const maxSpins = item.type === 'mystery' ? 24 : 18;

  v.innerHTML = `<div class="card grad center" style="min-height:220px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px">
    <div id="spinEmoji" style="font-size:70px;transition:transform .08s">🎲</div>
    <div id="spinLabel" class="muted" style="color:#fff;font-size:14px">${item.type==='mystery'?'Sirli sovg\'a ochilmoqda...':'Qayta ishlayapti...'}</div>
    <div style="display:flex;gap:6px;margin-top:4px">${emojis.slice(0,4).map(e=>`<span style="font-size:20px;opacity:.4">${e}</span>`).join('')}</div>
  </div>`;

  buzzOk();
  const el = $('#spinEmoji');
  const interval = setInterval(() => {
    const e = emojis[spinIdx % emojis.length];
    el.textContent = e;
    const scale = 1 + Math.abs(Math.sin(spinIdx * 0.4)) * 0.25;
    el.style.transform = `scale(${scale}) rotate(${(spinIdx%4)*5-10}deg)`;
    spinIdx++; spins++;
    if (spins >= maxSpins) {
      clearInterval(interval);
      // ── Sotib olish ──
      STATE.points -= item.price;
      STATE.purchased.push(itemId);
      // bonus_xp turidagi sovg'alar XP ham beradi
      if (item.type === 'bonus_xp' && item.bonusXp) {
        STATE.points += item.bonusXp;
        STATE.xp = (STATE.xp||0) + item.bonusXp;
      }
      save();
      el.textContent = item.icon;
      el.style.transform = 'scale(1.4)';
      buzzOk();

      // ── Reveal kartasi ──
      const typeLabels = {
        badge:'🏅 Nishon', bonus_xp:'⚡ XP Bonus', mystery:'🔮 Sirli sovg\'a',
        streak_shield:'🛡️ Streak himoya', avatar:'🎨 Avatar', idiom:'💬 Ibora',
        quote:'💬 Sitata', fact:'🧠 Fakt', tip:'📝 Maslahat', default:'🎁 Sovg\'a'
      };
      const label = typeLabels[item.type] || typeLabels.default;
      const revealLabel = item.reveal ? (typeLabels[item.reveal]||'') : '';

      setTimeout(() => {
        v.innerHTML = `
        <div class="card grad center" style="padding:28px;position:relative;overflow:hidden">
          <div style="position:absolute;top:0;left:0;right:0;bottom:0;opacity:.08;font-size:120px;display:flex;align-items:center;justify-content:center;pointer-events:none">${item.icon}</div>
          <div style="font-size:18px;color:rgba(255,255,255,.7);margin-bottom:8px">${revealLabel||label}</div>
          <div style="font-size:64px;margin:8px 0">${item.icon}</div>
          <h2 style="color:#fff;margin:10px 0 4px">${esc(item.name)}</h2>
          <div style="width:100%;background:rgba(255,255,255,.12);border-radius:14px;padding:14px 16px;margin:10px 0;font-size:15px;color:#fff;text-align:left;line-height:1.5">
            ${esc(item.reward)}
          </div>
          ${item.type==='bonus_xp'?`<div style="font-size:22px;color:#ffd54a;font-weight:800">+${item.bonusXp} XP ⚡</div>`:''}
          <div style="color:rgba(255,255,255,.6);font-size:13px;margin-top:6px">-${item.price} 💎</div>
        </div>
        <button class="btn" id="backShop" style="margin-top:14px">🎪 ${esc(t('shop'))}</button>
        <button class="btn sec" id="bHome" style="margin-top:8px">🏠</button>`;
        $('#backShop').onclick = () => go('shop');
        $('#bHome').onclick = () => go('home');
        updateHud();
      }, 500);
    }
  }, item.type==='mystery' ? 80 : 100);
}

/* ---------------- WEAK WORDS (bilmaydigan so'zlar) ---------------- */
function getWeakWords() {
  try {
    return STATE.words.filter(w => (w.wrongCount || 0) >= 1 && !w.learned)
      .sort((a,b) => (b.wrongCount||0) - (a.wrongCount||0));
  } catch(e) { return []; }
}
registerRoute('weak', (root) => {
  const weak = getWeakWords();
  if (!weak.length) {
    root.innerHTML = `<h1>\ud83d\udca1 ${esc(t('weakWords'))}</h1>
      <p class="empty"><span>\ud83c\udf89</span>${esc(t('noWeakWords'))}</p>
      <button class="btn sec" id="bHome">\ud83c\udfe0</button>`;
    $('#bHome').onclick = () => go('home');
    return;
  }
  // 10 talab bo'lib ko'rsatish
  const chunks = [];
  for (let i = 0; i < weak.length; i += 10) chunks.push(weak.slice(i, i+10));
  let page = 0;
  const draw = () => {
    const chunk = chunks[page];
    root.innerHTML = `
      <h1>\ud83d\udca1 ${esc(t('weakWords'))} <span class="muted" style="font-size:14px">${weak.length} ta</span></h1>
      <p class="muted">${esc(t('weakWordsDesc'))}</p>
      <div id="wList">
        ${chunk.map(w => `
          <div class="card" style="padding:12px">
            <div class="list-item" style="border:none;padding:0">
              <div style="flex:1">
                <div class="w">${esc(w.word)} <span class="pill hard">${w.wrongCount||0}x \u274c</span></div>
                <div class="t">${esc(w.tr)}</div>
              </div>
              <button class="speak" data-say="${esc(w.word)}">\ud83d\udd0a</button>
            </div>
            <div class="note" style="margin-top:6px">\u201c${esc(w.ex)}\u201d</div>
          </div>`).join('')}
      </div>
      ${chunks.length > 1 ? `<div class="row" style="margin-top:10px">
        <button class="btn sec" id="wPrev" ${page===0?'disabled':''}>\u2190</button>
        <span class="muted" style="align-self:center">${page+1}/${chunks.length}</span>
        <button class="btn sec" id="wNext" ${page>=chunks.length-1?'disabled':''}>\u2192</button>
      </div>` : ''}
      <button class="btn" id="wPractice" style="margin-top:14px">\ud83c\udfaf ${esc(t('practiceWeak'))}</button>
      <button class="btn sec" id="bHome" style="margin-top:10px">\ud83c\udfe0</button>`;
    $$('[data-say]', root).forEach(b => b.onclick = () => speak(b.dataset.say));
    const pr = $('#wPrev'); if(pr) pr.onclick = () => { page--; draw(); };
    const nx = $('#wNext'); if(nx) nx.onclick = () => { page++; draw(); };
    $('#wPractice').onclick = () => {
      // Bilmaydigan so'zlardan mashq boshlash
      const pool = weak.slice(0, 12);
      pool.forEach(w => { w.due = 0; }); // due qilib qo'yish
      save();
      go('learn');
    };
    $('#bHome').onclick = () => go('home');
  };
  draw();
});

/* ---------------- PRACTICE: drag & drop + SRS ---------------- */
let session = null;
registerRoute('learn', (root) => {
  const pool = dueWords();
  const cefr = getCefrLevel(STATE.points || 0);
  // Darajaga mos so'zlar mavjudligini tekshirish
  const maxDiff = cefrMaxDiff();
  const allForLevel = STATE.words.filter(w => (w.diff||1) <= maxDiff);
  const learnedCount = allForLevel.filter(w => w.learned).length;

  if (!pool.length) {
    const allLearned = learnedCount >= allForLevel.length && allForLevel.length > 0;
    root.innerHTML = `<h1>🎯 Mashq</h1>
      <div class="card" style="text-align:center;padding:24px 16px;">
        <div style="font-size:40px;">${allLearned ? '🏆' : '🎉'}</div>
        <h3 style="margin:8px 0;">${allLearned ? 'Barcha so\u02bcz o\u02bcz lashtirildi!' : 'Bugunlik tugadi!'}</h3>
        <div class="muted" style="font-size:13px;">${cefr.icon} ${cefr.id} darajasi uchun: ${learnedCount}/${allForLevel.length} so\u02bcz</div>
      </div>
      <button class="btn sec" id="bHome">🏠 Bosh sahifa</button>`;
    $('#bHome').onclick = () => go('home');
    return;
  }

  // O'zlashtirilgan so'zlar takrorlash uchun kelsa — alohida belgi
  const newWords = pool.filter(w => !w.learned);
  const reviewWords = pool.filter(w => w.learned);
  const sessionWords = shuffle([...newWords, ...reviewWords]).slice(0, 15);
  session = { queue: sessionWords, idx: 0, ok: 0 };
  renderCard(root);
});

function shuffle(a) { a = a.slice(); for (let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; }

function renderCard(root) {
  if (session.idx >= session.queue.length) { return renderSessionDone(root); }
  const w = session.queue[session.idx];
  // Har doim 4 ta variant (taxmin qilish qiyin)
  const distractorCount = Math.min(3, STATE.words.length - 1);
  const others = shuffle(STATE.words.filter(x => x.id !== w.id)).slice(0, distractorCount).map(x => x.tr);
  const options = shuffle([w.tr, ...others]);
  session.startTs = now();
  session.answered = false;

  const isReview = w.learned;
  const diffLabel = w.diff === 1 ? 'A1' : w.diff === 2 ? 'A2' : w.diff === 3 ? 'B1' : 'B2+';

  root.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
      <h1 style="margin:0;">${esc(t('learnTitle'))}</h1>
      <span class="muted" style="font-size:13px;">${session.idx+1}/${session.queue.length}</span>
    </div>
    <div style="display:flex;gap:6px;margin-bottom:10px;align-items:center;">
      <span style="font-size:11px;font-weight:700;padding:3px 8px;border-radius:999px;background:${w.diff===1?'#27c498':w.diff===2?'#ffb020':'#9b8cff'};color:#fff;">${diffLabel}</span>
      ${isReview ? '<span style="font-size:11px;padding:3px 8px;border-radius:999px;background:rgba(255,255,255,.1);color:var(--muted);">🔄 Takrorlash</span>' : '<span style="font-size:11px;padding:3px 8px;border-radius:999px;background:rgba(39,196,152,.15);color:var(--ok);">✨ Yangi</span>'}
    </div>
    <p class="muted center" style="margin-bottom:10px;">${esc(t('dragToCorrect'))}</p>
    <div class="dnd-word" id="dndWord">${esc(w.word)} <button class="speak" id="sayW">\ud83d\udd0a</button></div>
    <div id="zones" class="${options.length >= 4 ? 'zones-grid' : ''}">
      ${options.map((o,i)=>`<div class="drop-zone" data-tr="${esc(o)}">${esc(o)}</div>`).join('')}
    </div>
    <div id="feedback"></div>`;

  $('#sayW').onclick = (e) => { e.stopPropagation(); speak(w.word); };
  if (STATE.settings.autoSpeak) speak(w.word);
  setupDnd(root, w);
}

/* Drag the word chip onto a drop-zone. Works with mouse + touch (Pointer Events).
   Mobile APK fix: uses threshold so tap != drag, requestAnimationFrame for smooth movement. */
function setupDnd(root, w) {
  const chip = $('#dndWord');
  const zones = $$('.drop-zone', root);
  const DRAG_THRESHOLD = 8; // px - minimal movement before drag starts
  let pointerDown = false, dragging = false, ghost = null;
  let startX = 0, startY = 0, lastX = 0, lastY = 0;
  let rafId = 0;

  // Prevent default touch scrolling on the chip so drag works on mobile
  chip.style.touchAction = 'none';
  chip.style.userSelect = 'none';
  chip.style.webkitUserSelect = 'none';

  function createGhost(x, y) {
    ghost = chip.cloneNode(true);
    ghost.style.cssText = 'position:fixed;z-index:999;width:auto;min-width:120px;'
      + 'max-width:70vw;opacity:.92;pointer-events:none;transition:none;'
      + 'box-shadow:0 12px 32px rgba(0,0,0,.35);transform:scale(1.08);'
      + 'left:' + (x - 60) + 'px;top:' + (y - 30) + 'px;';
    document.body.appendChild(ghost);
    chip.style.opacity = '.3';
    chip.classList.add('dragging');
  }

  function moveGhost() {
    if (!ghost) return;
    ghost.style.left = (lastX - 60) + 'px';
    ghost.style.top = (lastY - 30) + 'px';
    // Highlight zones under finger
    zones.forEach(z => {
      const r = z.getBoundingClientRect();
      const over = lastX >= r.left && lastX <= r.right && lastY >= r.top && lastY <= r.bottom;
      z.classList.toggle('over', over);
    });
    rafId = 0;
  }

  const onDown = (e) => {
    if (session.answered) return;
    e.preventDefault();
    // Capture pointer for reliable tracking even outside element
    if (chip.setPointerCapture) {
      try { chip.setPointerCapture(e.pointerId); } catch(_){}
    }
    const p = point(e);
    startX = p.x; startY = p.y;
    lastX = p.x; lastY = p.y;
    pointerDown = true;
    dragging = false;
  };

  const onMove = (e) => {
    if (!pointerDown || session.answered) return;
    e.preventDefault();
    const p = point(e);
    lastX = p.x; lastY = p.y;

    // Start drag only after threshold (prevents accidental drags)
    if (!dragging) {
      const dx = p.x - startX, dy = p.y - startY;
      if (Math.sqrt(dx*dx + dy*dy) < DRAG_THRESHOLD) return;
      dragging = true;
      createGhost(p.x, p.y);
    }

    // Use rAF for smooth 60fps movement
    if (!rafId) rafId = requestAnimationFrame(moveGhost);
  };

  const onUp = (e) => {
    if (!pointerDown) return;
    pointerDown = false;
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }

    const p = point(e);

    if (!dragging) {
      // It was a tap, not a drag - ignore
      return;
    }

    dragging = false;
    let target = null;
    zones.forEach(z => {
      const r = z.getBoundingClientRect();
      if (p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom) target = z;
      z.classList.remove('over');
    });
    if (ghost) { ghost.remove(); ghost = null; }
    chip.style.opacity = '1';
    chip.classList.remove('dragging');
    if (target) handleDrop(target, w, root);
  };

  const onCancel = () => {
    pointerDown = false; dragging = false;
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    if (ghost) { ghost.remove(); ghost = null; }
    chip.style.opacity = '1';
    chip.classList.remove('dragging');
    zones.forEach(z => z.classList.remove('over'));
  };

  chip.addEventListener('pointerdown', onDown);
  chip.addEventListener('pointermove', onMove);
  chip.addEventListener('pointerup', onUp);
  chip.addEventListener('pointercancel', onCancel);
  // Fallback: window-level listeners for edge cases
  window.addEventListener('pointerup', onUp);
  window.addEventListener('pointercancel', onCancel);

  session._cleanup = () => {
    chip.removeEventListener('pointerdown', onDown);
    chip.removeEventListener('pointermove', onMove);
    chip.removeEventListener('pointerup', onUp);
    chip.removeEventListener('pointercancel', onCancel);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('pointercancel', onCancel);
    if (rafId) cancelAnimationFrame(rafId);
    if (ghost) { ghost.remove(); ghost = null; }
  };
}
function point(e) {
  if (e.touches && e.touches[0]) return { x: e.touches[0].clientX, y: e.touches[0].clientY };
  return { x: e.clientX, y: e.clientY };
}

function handleDrop(zone, w, root) {
  if (session.answered) return;
  session.answered = true;
  if (session._cleanup) session._cleanup();
  const correct = zone.dataset.tr === w.tr;
  const ms = now() - session.startTs;

  const fb = $('#feedback');

  if (!correct) {
    zone.classList.add('wrong');
    buzzWrong();
    w.seen++;
    if (!w.wrongCount) w.wrongCount = 0;
    w.wrongCount++;
    // Xato: correctStreak ni nolga tushir
    w.correctStreak = 0;
    w.due = now() + (STATE.settings.daysWrong || 1) * DAY;
    markStudiedToday(); save();
    fb.innerHTML = `<div class="card">
        <h3 style="color:var(--err)">❌ Xato</h3>
        <p><b>${esc(w.word)}</b> = <b>${esc(w.tr)}</b></p>
        <div class="note">\u201c${esc(w.ex)}\u201d</div>
        <div class="muted" style="font-size:12px;margin-top:6px;">⚠️ Ball berilmadi. So'z qaytadi.</div>
      </div>`;
    fb.innerHTML += `<button class="btn" id="bNext">${session.idx+1>=session.queue.length?esc(t('finish')):esc(t('next'))}</button>`;
    $('#bNext').onclick = () => { session.idx++; renderCard(root); };
    updateHud();
    return;
  }

  zone.classList.add('correct');
  buzzOk();
  session.ok++;
  w.seen++;

  // TAKRORLASH so'zi — ball yo'q, faqat vaqtini uzayt
  if (w.learned) {
    w.due = now() + 30 * DAY;
    markStudiedToday(); save();
    fb.innerHTML = `<div class="card" style="text-align:center">
        <h3 style="color:var(--ok);margin-bottom:4px;">✅ To'g'ri!</h3>
        <div style="color:var(--muted);font-size:13px;">🔄 Takrorlash — ball berilmaydi</div>
        <p style="margin:8px 0 0;font-size:13px;"><b>${esc(w.word)}</b> = ${esc(w.tr)}</p>
      </div>`;
    fb.innerHTML += `<button class="btn" id="bNext">${session.idx+1>=session.queue.length?esc(t('finish')):esc(t('next'))}</button>`;
    $('#bNext').onclick = () => { session.idx++; renderCard(root); };
    updateHud();
    return;
  }

  // YANGI so'z — streak tizimi
  if (!w.correctStreak) w.correctStreak = 0;
  w.correctStreak++;
  const streak = w.correctStreak;

  let reward = 0;
  let rewardMsg = '';
  let learnedNow = false;

  if (streak === 1) {
    reward = 5;
    rewardMsg = `<span style="color:var(--pri2);font-size:18px;">💎 +5</span> <span class="muted">Birinchi marta!</span>`;
    w.due = now() + (STATE.settings.daysEasy || 3) * DAY;
  } else if (streak === 2) {
    reward = 3;
    rewardMsg = `<span style="color:var(--pri2);font-size:18px;">💎 +3</span> <span class="muted">Ikkinchi marta</span>`;
    w.due = now() + 7 * DAY;
  } else if (streak === 3) {
    reward = 1;
    rewardMsg = `<span style="color:var(--pri2);font-size:18px;">💎 +1</span> <span class="muted">Uchinchi marta</span>`;
    w.due = now() + 14 * DAY;
  } else {
    reward = 0;
    learnedNow = !w.learned;
    w.learned = true;
    w.due = now() + 30 * DAY;
    rewardMsg = `<span style="color:var(--ok);font-size:18px;">⭐ O'zlashtirildi!</span> <span class="muted">Lug'atga qo'shildi</span>`;
    if (learnedNow) updatePassportVocab();
  }

  if (reward > 0) {
    STATE.points = (STATE.points || 0) + reward;
    STATE.xp = (STATE.xp || 0) + reward;
  }

  const progressDots = ['⬜','⬜','⬜','⬜'].map((_, i) =>
    i < streak ? (i === 3 ? '⭐' : '🟣') : '⬜'
  ).join(' ');

  markStudiedToday(); save();

  fb.innerHTML = `<div class="card" style="text-align:center">
      <h3 style="color:var(--ok);margin-bottom:4px;">✅ To'g'ri!</h3>
      <div style="margin-bottom:8px;">${rewardMsg}</div>
      <div style="font-size:20px;letter-spacing:4px;">${progressDots}</div>
      <div style="font-size:11px;color:var(--muted);margin-top:4px;">${streak}/4 — ${streak >= 4 ? "O'zlashtirilgan ✓" : (4 - streak) + " marta qoldi"}</div>
    </div>`;
  fb.innerHTML += `<button class="btn" id="bNext">${session.idx+1>=session.queue.length?esc(t('finish')):esc(t('next'))}</button>`;
  $('#bNext').onclick = () => { session.idx++; renderCard(root); };
  updateHud();
}

/* ---------------- WORD TEST (30-40 so'z, drag & drop, daraja bo'yicha) ---------------- */
let wordTest = null;
registerRoute('wordtest', (root) => {
  const cefr = getCefrLevel(STATE.points);
  // Daraja bo'yicha so'zlar: A1=diff1, A2=diff1-2, B1+=hammasi
  const maxDiff = cefrMaxDiff();
  const pool = STATE.words.filter(w => (w.diff||2) <= maxDiff);
  if (pool.length < 4) {
    root.innerHTML = `<h1>\ud83d\udcdd ${esc(t('wordTest'))}</h1>
      <p class="empty"><span>\ud83d\udcad</span>Kamida 4 ta so'z kerak</p>
      <button class="btn sec" id="bHome">\ud83c\udfe0</button>`;
    $('#bHome').onclick = () => go('home');
    return;
  }
  const count = Math.min(pool.length, 30 + Math.floor(Math.random()*11)); // 30-40
  wordTest = {
    queue: shuffle(pool).slice(0, count),
    idx: 0, correct: 0, wrong: [],
    startTime: now()
  };
  renderWordTest(root);
});

function renderWordTest(root) {
  const wt = wordTest;
  if (wt.idx >= wt.queue.length) return renderWordTestDone(root);
  const w = wt.queue[wt.idx];
  const distractorCount = Math.min(3, STATE.words.length - 1);
  const others = shuffle(STATE.words.filter(x => x.id !== w.id)).slice(0, distractorCount).map(x => x.tr);
  const options = shuffle([w.tr, ...others]);
  wt._answered = false;
  wt._startTs = now();

  root.innerHTML = `
    <h1>\ud83d\udcdd ${esc(t('wordTest'))} <span class="muted" style="font-size:14px">${wt.idx+1}/${wt.queue.length}</span></h1>
    <div class="bar"><i style="width:${Math.round(wt.idx/wt.queue.length*100)}%"></i></div>
    <p class="muted center">${esc(t('dragToCorrect'))}</p>
    <div class="dnd-word" id="dndWord">${esc(w.word)} <button class="speak" id="sayW">\ud83d\udd0a</button></div>
    <div id="zones" class="${options.length >= 4 ? 'zones-grid' : ''}">
      ${options.map(o => `<div class="drop-zone" data-tr="${esc(o)}">${esc(o)}</div>`).join('')}
    </div>
    <div id="feedback"></div>`;

  $('#sayW').onclick = (e) => { e.stopPropagation(); speak(w.word); };
  if (STATE.settings.autoSpeak) speak(w.word);
  setupWordTestDnd(root, w);
}

function setupWordTestDnd(root, w) {
  const chip = $('#dndWord');
  const zones = $$('.drop-zone', root);
  const DRAG_THRESHOLD = 8;
  let pointerDown = false, dragging = false, ghost = null;
  let startX=0, startY=0, lastX=0, lastY=0, rafId=0;
  chip.style.touchAction = 'none';
  chip.style.userSelect = 'none';

  const onDown = (e) => {
    if (wordTest._answered) return;
    e.preventDefault();
    if (chip.setPointerCapture) try{chip.setPointerCapture(e.pointerId);}catch(_){}
    const p = point(e); startX=p.x; startY=p.y; lastX=p.x; lastY=p.y;
    pointerDown = true; dragging = false;
  };
  const moveGhost = () => {
    if (!ghost) return;
    ghost.style.left = (lastX-60)+'px'; ghost.style.top = (lastY-30)+'px';
    zones.forEach(z => {
      const r = z.getBoundingClientRect();
      z.classList.toggle('over', lastX>=r.left && lastX<=r.right && lastY>=r.top && lastY<=r.bottom);
    });
    rafId = 0;
  };
  const onMove = (e) => {
    if (!pointerDown || wordTest._answered) return;
    e.preventDefault();
    const p = point(e); lastX=p.x; lastY=p.y;
    if (!dragging) {
      if (Math.sqrt((p.x-startX)**2+(p.y-startY)**2) < DRAG_THRESHOLD) return;
      dragging = true;
      ghost = chip.cloneNode(true);
      ghost.style.cssText = 'position:fixed;z-index:999;min-width:120px;max-width:70vw;opacity:.92;pointer-events:none;transition:none;box-shadow:0 12px 32px rgba(0,0,0,.35);transform:scale(1.08);left:'+(p.x-60)+'px;top:'+(p.y-30)+'px;';
      document.body.appendChild(ghost);
      chip.style.opacity = '.3';
    }
    if (!rafId) rafId = requestAnimationFrame(moveGhost);
  };
  const onUp = (e) => {
    if (!pointerDown) return;
    pointerDown = false;
    if (rafId) { cancelAnimationFrame(rafId); rafId=0; }
    if (!dragging) return;
    dragging = false;
    const p = point(e);
    let target = null;
    zones.forEach(z => {
      const r = z.getBoundingClientRect();
      if (p.x>=r.left && p.x<=r.right && p.y>=r.top && p.y<=r.bottom) target = z;
      z.classList.remove('over');
    });
    if (ghost) { ghost.remove(); ghost=null; }
    chip.style.opacity = '1';
    if (target) handleWordTestDrop(target, w, root);
  };
  const onCancel = () => {
    pointerDown=false; dragging=false;
    if (rafId){cancelAnimationFrame(rafId);rafId=0;}
    if (ghost){ghost.remove();ghost=null;}
    chip.style.opacity='1';
    zones.forEach(z=>z.classList.remove('over'));
  };
  chip.addEventListener('pointerdown',onDown);
  chip.addEventListener('pointermove',onMove);
  chip.addEventListener('pointerup',onUp);
  chip.addEventListener('pointercancel',onCancel);
  window.addEventListener('pointerup',onUp);
}

function handleWordTestDrop(zone, w, root) {
  if (wordTest._answered) return;
  wordTest._answered = true;
  const correct = zone.dataset.tr === w.tr;
  const ms = now() - wordTest._startTs;
  const diff = w.diff || 2;
  if (correct) {
    wordTest.correct++;
    zone.classList.add('correct');
    buzzOk();
    const base = diff >= 3 ? 8 : (diff >= 2 ? 5 : 3);
    addPoints(base, diff);
  } else {
    zone.classList.add('wrong');
    buzzWrong();
    wordTest.wrong.push(w);
    if (!w.wrongCount) w.wrongCount = 0;
    w.wrongCount++; w.lastWrong = now();
  }
  markStudiedToday(); save();
  const fb = $('#feedback');
  fb.innerHTML = correct
    ? `<div class="card center"><h3 style="color:var(--ok)">\u2705 ${esc(w.tr)}</h3></div>`
    : `<div class="card"><h3 style="color:var(--err)">\u274c ${esc(w.word)} = ${esc(w.tr)}</h3><div class="note">\u201c${esc(w.ex)}\u201d</div></div>`;
  fb.innerHTML += `<button class="btn" id="bNext">${wordTest.idx+1>=wordTest.queue.length?esc(t('finish')):esc(t('next'))}</button>`;
  $('#bNext').onclick = () => { wordTest.idx++; renderWordTest(root); };
  updateHud();
}

function renderWordTestDone(root) {
  const wt = wordTest;
  const pct = Math.round(wt.correct / wt.queue.length * 100);
  const secs = Math.round((now() - wt.startTime) / 1000);
  const mins = Math.floor(secs/60);
  root.innerHTML = `
    <h1>\ud83d\udcdd ${esc(t('wordTest'))} - ${esc(t('sessionDone'))}</h1>
    <div class="card grad center">
      <div style="font-size:50px;font-weight:800">${wt.correct}/${wt.queue.length}</div>
      <div style="font-size:20px">${pct}% \u2022 ${mins}:${String(secs%60).padStart(2,'0')}</div>
    </div>
    ${wt.wrong.length ? `<div class="card">
      <h3>\u274c ${esc(t('weakWords'))} (${wt.wrong.length})</h3>
      ${wt.wrong.map(w => `<div class="list-item"><div><b>${esc(w.word)}</b> = ${esc(w.tr)}</div></div>`).join('')}
    </div>` : `<div class="card center"><h3 style="color:var(--ok)">\ud83c\udf89 Mukammal!</h3></div>`}
    <button class="btn" id="tAgain">\ud83d\udd04 ${esc(t('again'))}</button>
    <button class="btn sec" id="bHome" style="margin-top:10px">\ud83c\udfe0</button>`;
  $('#tAgain').onclick = () => go('wordtest');
  $('#bHome').onclick = () => go('home');
}

/* ---------------- QUIZ (timed multiple-choice test) ---------------- */
let quiz = null;
registerRoute('quiz', (root) => {
  if (STATE.words.length < 4) {
    root.innerHTML = `<h1>\u23f1\ufe0f Quiz</h1>
      <p class="empty"><span>\ud83d\udcad</span>Kamida 4 ta so\u2019z kerak</p>
      <button class="btn sec" id="bHome">\ud83c\udfe0</button>`;
    $('#bHome').onclick = () => go('home');
    return;
  }
  quiz = { queue: shuffle(STATE.words).slice(0, 10), idx: 0, correct: 0, total: 0 };
  renderQuiz(root);
});

function renderQuiz(root) {
  if (quiz.idx >= quiz.queue.length) return renderQuizDone(root);
  const w = quiz.queue[quiz.idx];
  // ask in both directions randomly: word->tr or tr->word
  const reverse = Math.random() < 0.5;
  const askText = reverse ? w.tr : w.word;
  const answer  = reverse ? w.word : w.tr;
  const distractors = shuffle(STATE.words.filter(x => x.id !== w.id))
    .slice(0, 3).map(x => reverse ? x.word : x.tr);
  const options = shuffle([answer, ...distractors]);
  quiz._start = now();
  root.innerHTML = `
    <h1>\u23f1\ufe0f Quiz <span class="muted" style="font-size:14px">${quiz.idx+1}/${quiz.queue.length}</span></h1>
    <div class="bar"><i style="width:${Math.round(quiz.idx/quiz.queue.length*100)}%"></i></div>
    <div class="card center" style="margin-top:14px">
      <div style="font-size:30px;font-weight:800">${esc(askText)}</div>
      ${!reverse ? `<button class="speak" id="qSay" style="margin-top:8px">\ud83d\udd0a</button>` : ''}
    </div>
    <div id="qOpts">
      ${options.map(o => `<button class="btn sec quiz-opt" data-ans="${esc(o)}" style="margin-bottom:10px">${esc(o)}</button>`).join('')}
    </div>`;
  const say = $('#qSay'); if (say) say.onclick = () => speak(w.word);
  if (!reverse && STATE.settings.autoSpeak) speak(w.word);
  $$('.quiz-opt', root).forEach(btn => btn.onclick = () => {
    const ok = btn.dataset.ans === answer;
    quiz.total++;
    if (ok) { quiz.correct++; btn.classList.add('ok'); buzzOk(); addPoints(5); }
    else {
      btn.classList.add('err'); buzzWrong(); addPoints(-2);
      $$('.quiz-opt', root).forEach(b => { if (b.dataset.ans === answer) b.classList.add('ok'); });
    }
    $$('.quiz-opt', root).forEach(b => b.disabled = true);
    markStudiedToday(); save();
    setTimeout(() => { quiz.idx++; renderQuiz(root); }, 900);
  });
}

function renderQuizDone(root) {
  const pct = Math.round(quiz.correct / quiz.queue.length * 100);
  // Passport: quiz natijasini hozirgi darajaga saqlash
  const cefrNow = getCefrLevel(STATE.points || 0);
  updatePassportQuiz(cefrNow.id, pct);
  root.innerHTML = `<h1>\u23f1\ufe0f Quiz ${esc(t('sessionDone'))} \ud83c\udf8a</h1>
    <div class="card grad center">
      <div style="font-size:44px;font-weight:800">${quiz.correct}/${quiz.queue.length}</div>
      <div style="font-size:18px">${pct}%</div>
    </div>
    <button class="btn" id="qAgain">\ud83d\udd04 Qayta</button>
    <button class="btn sec" id="qHome" style="margin-top:10px">\ud83c\udfe0</button>`;
  $('#qAgain').onclick = () => go('quiz');
  $('#qHome').onclick = () => go('home');
}

/* ---------------- FLASHCARDS ---------------- */
/* Tap a card to flip: front = English word, back = Uzbek translation. */
let flashDeck = null;
registerRoute('flash', (root) => {
  const pool = STATE.words.slice();
  if (!pool.length) {
    root.innerHTML = `<h1>\ud83c\udccf Flashcards</h1>
      <p class="empty"><span>\ud83d\udcad</span>${esc(t('noWords'))}</p>
      <button class="btn sec" id="bHome">\ud83c\udfe0</button>`;
    $('#bHome').onclick = () => go('home');
    return;
  }
  flashDeck = { cards: shuffle(pool), idx: 0, flipped: false };
  renderFlash(root);
});

function renderFlash(root) {
  const d = flashDeck;
  const w = d.cards[d.idx];
  root.innerHTML = `
    <h1>\u270d\ufe0f Flashcards <span class="muted" style="font-size:14px">${d.idx+1}/${d.cards.length}</span></h1>
    <div class="flashcard ${d.flipped?'flipped':''}" id="fc">
      <div class="fc-inner">
        <div class="fc-front">
          <div class="fc-word">${esc(w.word)}</div>
          <button class="speak" id="fcSay">\ud83d\udd0a</button>
          <div class="muted" style="margin-top:12px">${esc(t('dragToCorrect') ? 'Tarjimani ko\u2019rish uchun bosing' : '')}</div>
        </div>
        <div class="fc-back">
          <div class="fc-tr">${esc(w.tr)}</div>
          <div class="note" style="margin-top:12px">\u201c${esc(w.ex)}\u201d</div>
        </div>
      </div>
    </div>
    <div class="row" style="margin-top:16px">
      <button class="btn sec" id="fcPrev">\u2190</button>
      <button class="btn" id="fcFlip">\ud83d\udd04</button>
      <button class="btn sec" id="fcNext">\u2192</button>
    </div>
    <button class="btn sec" id="fcHome" style="margin-top:10px">\ud83c\udfe0</button>`;

  const flip = () => { d.flipped = !d.flipped; renderFlash(root); };
  $('#fc').onclick = (e) => { if (e.target.id !== 'fcSay') flip(); };
  $('#fcFlip').onclick = flip;
  $('#fcSay').onclick = (e) => { e.stopPropagation(); speak(w.word); };
  $('#fcPrev').onclick = () => { d.idx = (d.idx - 1 + d.cards.length) % d.cards.length; d.flipped = false; renderFlash(root); };
  $('#fcNext').onclick = () => { d.idx = (d.idx + 1) % d.cards.length; d.flipped = false; renderFlash(root); };
  $('#fcHome').onclick = () => go('home');
  if (STATE.settings.autoSpeak) speak(w.word);
}

function renderSessionDone(root) {
  root.innerHTML = `<h1>${esc(t('sessionDone'))} \ud83c\udf8a</h1>
    <div class="card grad center">
      <div style="font-size:40px">\u2705 ${session.ok}/${session.queue.length}</div>
    </div>
    <button class="btn" id="again">${esc(t('startReview'))}</button>
    <button class="btn sec" id="home" style="margin-top:10px">\ud83c\udfe0</button>`;
  $('#again').onclick = () => go('learn');
  $('#home').onclick = () => go('home');
}

/* ---------------- STARTUP ---------------- */
document.addEventListener('DOMContentLoaded', () => {
  // Apply saved theme
  document.documentElement.setAttribute('data-theme', STATE.settings.theme || 'dark');

  // Wire up bottom nav tabs
  $$('.tab').forEach(btn => {
    btn.addEventListener('click', () => go(btn.dataset.route));
  });

  // Update HUD (points, streak, level)
  function updateHud() {
    const lvl = getCefrLevel ? getCefrLevel(STATE.points || 0) : null;
    const el = $('#hudPoints'); if (el) el.textContent = STATE.points || 0;
    const es = $('#hudStreak'); if (es) es.textContent = STATE.streak || 0;
    const el2 = $('#hudLevel'); if (el2) el2.textContent = STATE.level || 1;
  }
  updateHud();

  // Navigate to home on start
  go('home');
});
